# HEART — Molecular Pretraining and Lipid Continual Training

This repository is the **active Home checkout** at
`/home/ypan/heart_liver/model_train/heart-molecular-pretraining`.
It contains the completed general molecular pretraining workflow and the Ugi-4CR
lipid-library / continual-pretraining pipeline. The previous `heart-molecular-pretraining-v2`
checkout is preserved temporarily as a rollback copy until acceptance tests pass;
**do not delete it automatically**. Internal Python/CLI names (`heart_v2`,
`config/heart_v2.yaml`, `HEART_V2_*`) are retained for backward compatibility.

## Current status (2026-11-16)

- **General H200 pretraining**: completed 1,000,000 updates; existing checkpoint
  under `/project/yli4/ypan/runs/h200/full/heart-h200-b448-v1/` is read-only.
- **Lipid library**: Stage 01-04 completed, 3,049 shards, 15,182,715 stored
  molecules copied to `/project/yli4/ypan/lipid_library`.
- **Stage 05**: manifest, splits and audit exist; production QC **FAILED** on 2D
  fallback criteria. No training-ready declaration should be inferred from the
  presence of `splits.json`.
- **Stage 06 continual pretraining**: NOT launched. First run the four conformer
  tests and validate a training-view policy. The path migration changes no
  scientific settings, model, 2D policy, or training data.

## Deployment roots

| Purpose | Directory |
|---|---|
| Maintained source code and conda | `/home/ypan/heart_liver/model_train/heart-molecular-pretraining`, `/home/ypan/.conda/envs/heart_gpu` |
| Uni-Core source | `/home/ypan/heart_liver/model_train/third_party/Uni-Core` |
| General LMDB | `/project/yli4/ypan/UniMolReference/ligand_data/ligands` |
| Lipid library (original immutable Stage 01-04 shards) | `/project/yli4/ypan/lipid_library` |
| General checkpoint, continual checkpoints | `/project/yli4/ypan/runs/h200/full`, `/project/yli4/ypan/runs/h200/continual` |
| **ALL training stdout/stderr** (General H200, T4 legacy launchers, smoke, Continual) | **`/project/yli4/ypan/runs/h200/slurm`** |
| Lipid library Stage 01-06 job logs | `/project/yli4/ypan/lipid_library/logs` |

The `#SBATCH --output/--error` directories must exist **before** `sbatch`.
The General Pretraining scripts are standalone and do not read `heart_v2.yaml`;
their path defaults, comments, and Slurm headers have been updated separately.

## Safe read-only validation after deployment

```bash
cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining
mkdir -p /project/yli4/ypan/runs/h200/slurm
bin/heart baseline                 # original science plus approved path-only exceptions
bin/heart check                    # configuration and Slurm guards
bin/heart render continual         # preview only, does not submit
python scripts/verify_project_layout.py
```

**Never submit library regeneration or continual training to test path migration**.
`bin/heart library --resume --submit` and `bin/heart continual --submit` are NOT
read-only commands. Start with the four-test audit notebook before Stage 05/06 decisions.

## Implementation and provenance

- [General baseline integrity and approved deployment-only migrations](docs/GENERAL_BASELINE_INTEGRITY.md)
- [Project path migration and acceptance checks](PROJECT_PATH_MIGRATION_README.md)
- [Stage 05/06 quality requirements](docs/LIBRARY_QUALITY_CRITERIA.md)
- [HPC installation and recovery](docs/HPC_INSTALL_AND_RECOVERY.md)

Uni-Mol and LUMI-lab code retains its original third-party licences in `model/unimol`.
