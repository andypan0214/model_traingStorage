#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH --time=06:00:00
#SBATCH --job-name=lipid-03-dedup
#SBATCH --output=/project/yli4/ypan/lipid_library/logs/%x-%j.out
#SBATCH --error=/project/yli4/ypan/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 03 (CPU): global duplicate-product detection (external sort + merge;
# memory is one chunk plus the drop list). Run after every stage-02 task:
#   HEART_CONFIRM_LIPID=1 sbatch --export=ALL --dependency=afterok:<02 array id> \
#       scripts/lipid_library/03_dedup.sh
# It refuses to start while any enumeration chunk receipt is missing.
# =============================================================================
set -eo pipefail
# v2: locate THIS checkout (sbatch runs a spooled copy); never fall back to the old clone.
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$here/lipid_lib.sh" ]; then
    if [ -n "${HEART_REPO:-}" ]; then
        here="$HEART_REPO/model/pretrain/scripts/lipid_library"
    elif [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
        here="$(dirname "$(scontrol show job "$SLURM_JOB_ID" | sed -n 's/^ *Command=//p' | head -1 | cut -d' ' -f1)")"
    fi
fi
[ -f "$here/lipid_lib.sh" ] || { echo "ERROR: cannot locate scripts/lipid_library (set HEART_REPO)" >&2; exit 1; }
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/03_dedup.sh"
"$PY" -m lipid_library.enumerate_library "$LIPID_BB" -o "$LIPID_ENUM" \
    --chunk-size "${CHUNK_SIZE:-50000}" --check-complete \
    || die "enumeration is incomplete: resubmit stage 02 (completed chunks are skipped)"
tmp="${TMPDIR:-$LIPID_ROOT/tmp}"
mkdir -p "$tmp"
"$PY" -m lipid_library.dedup "$LIPID_ENUM" -o "$LIPID_DEDUP" --tmp-dir "$tmp" --require-complete
