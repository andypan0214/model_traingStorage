#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=32G
#SBATCH --time=12:00:00
#SBATCH --job-name=lipid-06-verify
#SBATCH --output=/project/yli4/ypan/lipid_library/logs/%x-%j.out
#SBATCH --error=/project/yli4/ypan/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 06: ONE-TIME production 3D-aware view readiness verification.
# Uses the completed Stage-04 LMDB shards and existing train/valid splits.
# Full SHA256 of every LMDB and all 3D sidecar indexes is done ONCE here.
# Later continual preflights use the lightweight pinned readiness receipt.
# Usage: sbatch model/pretrain/scripts/lipid_library/06_verify_library.sh
# Does not rewrite manifest/splits/quality_report or any LMDB.
# =============================================================================
set -eo pipefail
# Locate this Home checkout (sbatch may run a spooled copy); no legacy checkout fallback.
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$here/lipid_lib.sh" ]; then
    if [ -n "${HEART_REPO:-}" ]; then
        here="$HEART_REPO/model/pretrain/scripts/lipid_library"
    elif [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
        here="$(dirname "$(scontrol show job "$SLURM_JOB_ID" | sed -n 's/^ *Command=//p' | head -1 | cut -d' ' -f1)")"
    fi
fi
[ -f "$here/lipid_lib.sh" ] || { echo "ERROR: cannot locate scripts/lipid_library (set HEART_REPO)" >&2; exit 1; }
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/06_verify_library.sh"
view="${HEART_LIPID_3D_VIEW:-/project/yli4/ypan/audits/ugi_3d_final_view/final_dataset_view.json}"
[ -r "$view" ] || die "validated 3D view absent: $view"
if [ -f "$LIPID_LMDB/library_3d_ready.json" ]; then
    "$PY" -m lipid_library.ready verify-3d "$LIPID_LMDB" --view "$view" \
        || die "Existing verified view receipt is invalid; inspect before rerunning the full hash"
    log "Stage 06 already verified: no full LMDB rehash needed"
    exit 0
fi
"$PY" -m lipid_library.ready write-3d "$LIPID_LMDB" --view "$view" \
    --workers "${SLURM_CPUS_PER_TASK:-16}" || die "3D-aware Stage 06 verification FAILED"
log "Stage 06 PASS: $LIPID_LMDB/library_3d_ready.json; splits and sidecar pinned"
