#!/usr/bin/env bash
# =============================================================================
# SUPERSEDED in HEART v2 -- intentionally declares NO SLURM directives and submits nothing.
#
# This v1 launcher carried its own copy of the SLURM resources (e.g. a generic
# --gres=gpu:1 header next to a gpu:h200:1 command line), i.e. a competing source
# of truth. All lipid/continual resources now live in config/heart_v2.yaml and
# are rendered by bin/heart, which prints the exact sbatch command first.
#
# Use instead (from the repository root):
#   bin/heart library --dry-run   (stage 04 = scripts/lipid_library/04_conformers_pool.sh, profile lipid_04)
# See docs/HPC_INSTALL_AND_RECOVERY.md.
# =============================================================================
echo "ERROR: $(basename "$0") is superseded in HEART v2. Use: bin/heart library --dry-run   (stage 04 = scripts/lipid_library/04_conformers_pool.sh, profile lipid_04)" >&2
exit 2
