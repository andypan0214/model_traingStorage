"""Patch P6: SMILES that cannot give an aligned RDKit 2D conformer (full job 1011523).

Job 1011523 crashed after ~5,000 updates with
    Boost.Python.ArgumentError: rdkit.Chem.rdmolops.AddHs(NoneType)
in Add2DConformerDataset: Chem.MolFromSmiles(smi) returned None for a record
that still had stored 3D conformers. These tests use synthetic records and a
synthetic LMDB only; the real 18.8M-record LMDB is never touched.
"""
import logging
import os
import pickle
import shutil

import numpy as np
import pytest
import torch

from conftest import task_args

VALID = ["CCO", "c1ccccc1", "C[C@@H](N)C(=O)O", "CCN(CC)CC"]
UNUSUAL_VALID = [
    "[Na+].[Cl-]",                    # salt, disconnected fragments
    "C[N+](C)(C)CC(=O)[O-]",          # zwitterion
    "[2H]C([2H])([2H])O",             # isotopes
    "C1CCCCCCCCCCCCCCCCCCC1",         # macrocycle
    "F/C=C/F",                        # double-bond stereo
    "[Cu+2]",                         # metal ion, no hydrogens
    "OB(O)c1ccccc1",                  # boronic acid
    "c1ccc2ccccc2c1",                 # fused aromatics
    "[nH]1cccc1",                     # aromatic NH
    "O",                              # water: 3 atoms after AddHs
    "[H][H]",                         # explicit hydrogens only
]
INVALID = {
    "C1CC": "SMILES syntax rejected",                       # unclosed ring
    "c1cccc1": "Can't kekulize",                            # sanitization: kekulization
    "C[N](C)(C)(C)C": "Explicit valence",                   # sanitization: valence
    "": "SMILES is empty",
    "   ": "SMILES is empty",
    None: "SMILES is NoneType, not a string",
    3: "SMILES is int, not a string",
    float("nan"): "SMILES is float, not a string",
    b"CCO": "SMILES is bytes, not a string",
    ("CCO",): "SMILES is tuple, not a string",
}


@pytest.fixture(scope="module")
def add2d(unimol_pkg):
    from unimol.data import add_2d_conformer_dataset

    return add_2d_conformer_dataset


def h_atoms(smi):
    from rdkit import Chem

    return [a.GetSymbol() for a in Chem.AddHs(Chem.MolFromSmiles(smi)).GetAtoms()]


def fake_3d(n_atoms, n_conf=2, seed=0):
    rng = np.random.RandomState(seed)
    return [rng.randn(n_atoms, 3).astype(np.float32) for _ in range(n_conf)]


# --------------------------------------------------------------------------- smi2_2Dcoords
@pytest.mark.parametrize("smi", VALID + UNUSUAL_VALID)
def test_valid_smiles_give_aligned_2d_coordinates(add2d, smi):
    atoms = h_atoms(smi)
    xy = add2d.smi2_2Dcoords(smi, atoms)
    assert xy.dtype == np.float32 and xy.shape == (len(atoms), 3)
    assert np.isfinite(xy).all() and np.allclose(xy[:, 2], 0.0)   # a 2D layout
    # identical to the upstream computation for valid molecules
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = AllChem.AddHs(Chem.MolFromSmiles(smi))
    AllChem.Compute2DCoords(mol)
    assert np.array_equal(xy, mol.GetConformer().GetPositions().astype(np.float32))


def test_valid_smiles_without_atoms_argument_is_upstream_compatible(add2d):
    assert add2d.smi2_2Dcoords("CCO").shape == (9, 3)


@pytest.mark.parametrize("smi,reason", list(INVALID.items()), ids=[repr(k) for k in INVALID])
def test_invalid_or_unexpected_smiles_raise_a_clear_reason(add2d, smi, reason):
    with pytest.raises(add2d.Invalid2DConformer, match=None) as exc:
        add2d.smi2_2Dcoords(smi, ["C"])
    assert reason in str(exc.value)
    assert isinstance(exc.value, ValueError)            # never Boost.Python.ArgumentError


def test_rdkit_messages_replaced_by_heart_diagnostics(add2d, capfd):
    for smi in ("C1CC", "c1cccc1", "C[N](C)(C)(C)C"):
        with pytest.raises(add2d.Invalid2DConformer):
            add2d.smi2_2Dcoords(smi)
    err = capfd.readouterr().err
    # RDKit's own "SMILES Parse Error:" lines would be counted as errors by summarize_log.py
    assert "Error:" not in err and "Explicit valence" not in err


def test_atom_order_or_count_mismatch_is_rejected(add2d):
    atoms = h_atoms("CCO")                               # C C O H H H H H H
    add2d.smi2_2Dcoords("CCO", atoms)
    with pytest.raises(add2d.Invalid2DConformer, match="differs from the record at atom 0"):
        add2d.smi2_2Dcoords("CCO", ["O"] + atoms[:1] + atoms[2:])
    with pytest.raises(add2d.Invalid2DConformer, match="2D molecule has 9 atoms, record has 3"):
        add2d.smi2_2Dcoords("CCO", ["C", "C", "O"])      # heavy atoms only
    with pytest.raises(add2d.Invalid2DConformer, match="2D molecule has 12 atoms, record has 9"):
        add2d.smi2_2Dcoords("c1ccccc1", atoms)           # another molecule's record


# --------------------------------------------------------------------------- Add2DConformerDataset
class ListDataset(torch.utils.data.Dataset):
    def __init__(self, records):
        self.records = records

    def __len__(self):
        return len(self.records)

    def __getitem__(self, i):
        return self.records[i]


def make_records():
    good = h_atoms("CCO")
    return [
        {"smi": "CCO", "atoms": good, "coordinates": fake_3d(9, seed=0)},
        {"smi": "C1CC", "atoms": good, "coordinates": fake_3d(9, seed=1)},          # invalid SMILES
        {"smi": None, "atoms": good, "coordinates": fake_3d(9, seed=2)},            # null SMILES
        {"smi": "c1ccccc1", "atoms": good, "coordinates": fake_3d(9, seed=3)},      # wrong molecule
        {"smi": "C1CC", "atoms": good, "coordinates": []},                          # nothing usable
    ]


def test_dataset_valid_record_gets_2d_conformer_and_cache_is_not_mutated(add2d):
    recs = make_records()
    ds = add2d.Add2DConformerDataset(ListDataset(recs), "smi", "atoms", "coordinates")
    ds.set_epoch(1)
    out = ds[0]
    assert len(out["coordinates"]) == 3 and len(recs[0]["coordinates"]) == 2      # P2 still holds
    assert out["coordinates"][0] is recs[0]["coordinates"][0]
    assert out["coordinates"][2].shape == (9, 3) and np.allclose(out["coordinates"][2][:, 2], 0)
    assert ds.n_skipped == 0


@pytest.mark.parametrize("index", [1, 2, 3])
def test_dataset_unusable_smiles_keeps_stored_3d_only(add2d, index, caplog):
    recs = make_records()
    ds = add2d.Add2DConformerDataset(ListDataset(recs), "smi", "atoms", "coordinates")
    ds.set_epoch(1)
    with caplog.at_level(logging.WARNING):
        out = ds[index]
    stored = recs[index]["coordinates"]
    assert len(out["coordinates"]) == len(stored) == 2                  # nothing fabricated
    assert all(a is b for a, b in zip(out["coordinates"], stored))       # the stored conformers, unchanged
    assert list(out["atoms"]) == recs[index]["atoms"] and out["smi"] == recs[index]["smi"]
    assert ds.n_skipped == 1 and len(ds) == len(recs)                    # indexing unchanged
    msg = caplog.text
    assert "HEART 2D conformer skipped: record {}".format(index) in msg and "2 stored 3D conformer" in msg
    assert "Error:" not in msg                                           # not a summarize_log error line


def test_dataset_without_any_usable_conformer_raises(add2d):
    ds = add2d.Add2DConformerDataset(ListDataset(make_records()), "smi", "atoms", "coordinates")
    ds.set_epoch(1)
    with pytest.raises(add2d.Invalid2DConformer, match="record 4 .*no stored 3D conformer"):
        ds[4]


def test_dataset_error_policy_stops_on_first_bad_record(add2d):
    ds = add2d.Add2DConformerDataset(ListDataset(make_records()), "smi", "atoms", "coordinates",
                                     invalid_policy="error")
    ds.set_epoch(1)
    ds[0]
    with pytest.raises(add2d.Invalid2DConformer, match="record 1 .*invalid-smiles-policy error"):
        ds[1]
    with pytest.raises(ValueError, match="invalid_policy"):
        add2d.Add2DConformerDataset(ListDataset([]), "smi", "atoms", "coordinates", invalid_policy="drop")


def test_dataset_stops_on_systematic_failure_rate(add2d):
    good = h_atoms("CCO")
    recs = [{"smi": "CCO" if i % 2 else "C1CC", "atoms": good, "coordinates": fake_3d(9, 1, i)}
            for i in range(40)]
    ds = add2d.Add2DConformerDataset(ListDataset(recs), "smi", "atoms", "coordinates",
                                     max_invalid_fraction=0.2, min_checked=20)
    ds.set_epoch(1)
    with pytest.raises(add2d.Invalid2DConformer, match="systematic"):
        for i in range(len(recs)):
            ds[i]
    assert ds.n_checked == 21 and ds.n_skipped == 11    # first skip after min_checked records


def test_dataset_is_deterministic(add2d):
    a = add2d.Add2DConformerDataset(ListDataset(make_records()), "smi", "atoms", "coordinates")
    b = add2d.Add2DConformerDataset(ListDataset(make_records()), "smi", "atoms", "coordinates")
    for ds in (a, b):
        ds.set_epoch(3)
    for i in range(4):
        ca, cb = a[i]["coordinates"], b[i]["coordinates"]
        assert len(ca) == len(cb) and all(np.array_equal(x, y) for x, y in zip(ca, cb))


# --------------------------------------------------------------------------- LMDB + full HEART task
@pytest.fixture(scope="module")
def bad_lmdb_dir(tmp_path_factory, fixture_info):
    """A copy of the fixture whose train.lmdb contains unusable SMILES next to valid 3D data."""
    import make_fixture_lmdb

    out = tmp_path_factory.mktemp("heart_bad_smiles")
    recs = [dict(r) for r in fixture_info["records"]]
    recs[1]["smi"] = "C1CC"                         # syntax error
    recs[3]["smi"] = "c1cccc1"                      # kekulization failure
    recs[4]["smi"] = None                           # null
    recs[5]["smi"] = ""                             # empty
    make_fixture_lmdb.write_lmdb(str(out / "train.lmdb"), recs[:6])
    make_fixture_lmdb.write_lmdb(str(out / "valid.lmdb"), recs[6:])
    shutil.copyfile(os.path.join(fixture_info["dir"], "dict.txt"), str(out / "dict.txt"))
    return str(out)


def build_task_dataset(data_dir, split="train", **overrides):
    from unimol.tasks.unimol_contrastive import UniMolTaskContrastive

    task = UniMolTaskContrastive.setup_task(task_args(data_dir, **overrides))
    task.load_dataset(split)
    ds = task.dataset(split)
    ds.set_epoch(1)
    return task, ds


def _same(a, b):
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(_same(a[k], b[k]) for k in a)
    if torch.is_tensor(a):
        return torch.equal(a, b)
    return a == b


def test_existing_fixture_lmdb_every_record_gets_its_2d_conformer(unimol_pkg, fixture_dir):
    from unimol.data import Add2DConformerDataset, LMDBDataset

    raw = LMDBDataset(os.path.join(fixture_dir, "train.lmdb"))
    ds = Add2DConformerDataset(raw, "smi", "atoms", "coordinates")
    ds.set_epoch(1)
    for i in range(len(raw)):
        rec = raw[i]
        out = ds[i]
        assert len(out["coordinates"]) == len(rec["coordinates"]) + 1
        assert all(c.shape == (len(rec["atoms"]), 3) for c in out["coordinates"])
    assert ds.n_skipped == 0 and ds.n_checked == len(raw)


def test_task_trains_through_bad_records_with_unchanged_indexing(unimol_pkg, bad_lmdb_dir, caplog):
    with caplog.at_level(logging.WARNING):
        task, ds = build_task_dataset(bad_lmdb_dir)
        assert len(ds) == 6                                              # no record dropped
        batch = ds.collater([ds[i] for i in range(len(ds))])
    pad = task.dictionary.pad()
    toks = batch["net_input"]["src_tokens"]
    assert toks.size(0) == 12                                            # 6 molecules x 2 views
    assert torch.isfinite(batch["net_input"]["src_coord"]).all()
    assert batch["target"]["tokens_target"].ne(pad).any()
    for i in (1, 3, 4, 5):
        assert "skipped: record {} ".format(i) in caplog.text
    # atom-coordinate alignment: per molecule, tokens and coordinates have the same length
    for v in range(12):
        n_tok = int(toks[v].ne(pad).sum())
        n_xyz = int(batch["net_input"]["src_coord"][v].abs().sum(-1).gt(0).sum())
        assert n_xyz <= n_tok


def test_task_on_bad_records_is_deterministic(unimol_pkg, bad_lmdb_dir):
    _, a = build_task_dataset(bad_lmdb_dir)
    _, b = build_task_dataset(bad_lmdb_dir)
    for i in range(len(a)):
        assert _same(a[i], b[i])


def test_task_error_policy_and_cli_defaults(unimol_pkg, bad_lmdb_dir):
    from unimol.data import add_2d_conformer_dataset as m

    _, ds = build_task_dataset(bad_lmdb_dir, invalid_smiles_policy="error")
    ds[0]
    with pytest.raises(m.Invalid2DConformer, match="record 1 "):
        ds[1]

    import argparse

    from unimol.tasks.unimol_contrastive import UniMolTaskContrastive

    p = argparse.ArgumentParser()
    UniMolTaskContrastive.add_args(p)
    ns = p.parse_args(["data"])
    assert ns.invalid_smiles_policy == "skip-2d" and ns.max_invalid_smiles_fraction == 0.01
    with pytest.raises(SystemExit):
        p.parse_args(["data", "--invalid-smiles-policy", "zero-coords"])


# --------------------------------------------------------------------------- scan tool (read-only)
def test_scan_tool_reports_problem_records(bad_lmdb_dir, tmp_path):
    import json

    import scan_lmdb_smiles

    lmdb_path = os.path.join(bad_lmdb_dir, "train.lmdb")
    before = os.path.getmtime(lmdb_path), os.path.getsize(lmdb_path)
    rc = scan_lmdb_smiles.main([lmdb_path, "--out-dir", str(tmp_path / "scan"), "--progress", "0"])
    assert rc == 1                                                       # 4/6 skipped > 1 %
    summary = json.loads((tmp_path / "scan" / "summary.json").read_text())
    assert summary["scanned"] == 6 and summary["records_2d_skipped"] == 4 and summary["records_fatal"] == 0
    assert summary["categories"] == {"smiles_empty": 1, "smiles_not_string": 1, "smiles_sanitize": 1,
                                     "smiles_syntax": 1}
    rows = (tmp_path / "scan" / "problems.tsv").read_text().splitlines()
    assert rows[0].split("\t") == ["index", "category", "severity", "reason", "smi"]
    assert sorted(int(r.split("\t")[0]) for r in rows[1:]) == [1, 3, 4, 5]
    assert (os.path.getmtime(lmdb_path), os.path.getsize(lmdb_path)) == before

    rc = scan_lmdb_smiles.main([lmdb_path, "--out-dir", str(tmp_path / "s2"), "--progress", "0",
                                "--max-skip-fraction", "1", "--fast"])
    assert rc == 0
    rc = scan_lmdb_smiles.main([lmdb_path, "--out-dir", str(tmp_path / "s3"), "--sample", "3", "--progress", "0",
                                "--max-skip-fraction", "1"])
    assert rc == 0 and json.loads((tmp_path / "s3" / "summary.json").read_text())["scanned"] == 3
    rc = scan_lmdb_smiles.main([lmdb_path, "--out-dir", str(tmp_path / "s4"), "--start", "2", "--end", "4",
                                "--progress", "0", "--max-skip-fraction", "1"])
    s4 = json.loads((tmp_path / "s4" / "summary.json").read_text())
    assert rc == 0 and s4["scanned"] == 2 and s4["records_2d_skipped"] == 1


def test_scan_tool_flags_fatal_records_and_refuses_output_in_data_dir(tmp_path):
    import make_fixture_lmdb
    import scan_lmdb_smiles

    good = h_atoms("CCO")
    recs = [
        {"smi": "CCO", "atoms": good, "coordinates": fake_3d(9)},
        {"smi": "CCO", "atoms": good, "coordinates": []},
        {"smi": "CCO", "atoms": good, "coordinates": fake_3d(8)},
        {"smi": "CCO", "atoms": good, "coordinates": [np.full((9, 3), np.nan, np.float32)]},
        {"smi": "CCO", "atoms": []},
    ]
    data = tmp_path / "data"
    data.mkdir()
    make_fixture_lmdb.write_lmdb(str(data / "train.lmdb"), recs)
    rc = scan_lmdb_smiles.main([str(data / "train.lmdb"), "--out-dir", str(tmp_path / "scan"), "--progress", "0"])
    import json

    summary = json.loads((tmp_path / "scan" / "summary.json").read_text())
    assert rc == 1 and summary["records_fatal"] == 4
    assert {"no_3d_conformer", "3d_shape_mismatch", "3d_nonfinite", "missing_field"} <= set(summary["categories"])
    assert scan_lmdb_smiles.main([str(data / "train.lmdb"), "--out-dir", str(data / "out")]) == 2
    assert not (data / "out").exists()


def test_summarize_log_counts_skipped_2d_records_without_failing(tmp_path, capsys):
    import summarize_log

    log = tmp_path / "train.log"
    log.write_text(
        "2026-11-02 10:00:00 | WARNING | unimol.data.add_2d_conformer_dataset | HEART 2D conformer skipped: "
        "record 7 (pid 1): SMILES syntax rejected by RDKit; smi='C1CC'; using its 10 stored 3D conformer(s)\n"
        "2026-11-02 10:00:00 | WARNING | unimol.data.add_2d_conformer_dataset | HEART 2D conformer skipped "
        "for 20 of 51234 records processed so far (pid 1)\n"
        "2026-11-02 10:00:01 | INFO | train_inner | epoch 001:      1 / 9 loss=27.4, num_updates=1\n"
        "2026-11-02 10:00:02 | INFO | valid | epoch 001 | valid on 'valid' subset | loss 26.1 | num_updates 1\n"
        "2026-11-02 10:00:03 | INFO | unicore.checkpoint_utils | Saved checkpoint /r/checkpoint_last.pt "
        "(epoch 1 @ 1 updates, score 26.1)\n", encoding="utf-8")
    assert summarize_log.main([str(log), "--expect-updates", "1"]) == 0
    out = capsys.readouterr().out
    assert "records without a 2D conformer (invalid SMILES, logged by patch P6): 20" in out
    assert "record 7 (pid 1)" in out
