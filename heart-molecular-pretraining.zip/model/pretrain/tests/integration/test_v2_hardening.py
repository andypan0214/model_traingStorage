"""HEART v2 hardening pass (PR #1 review): regression tests.

P0-1 mandatory general ligand slot-policy check before stage 04
P0-2 shard integrity: quick (size/sampled digest/mtime) + full sha256 + max age
P1-3 configuration drift fails closed (incl. the JSON snapshot round trip)
P1-5 stage-05 production-quality criteria
P2-7 10 slots != 10 distinct 3D conformers (seed_start=0) is measured and reported
P2-8 benchmark launcher and report
P2-9 GPU type detection from scontrol / nvidia-smi
"""
import json
import os
import pickle
import shutil
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import v2_helpers as h  # noqa: E402
from v2_fixtures import v2_library  # noqa: E402,F401

pytest.importorskip("rdkit")
pytest.importorskip("lmdb")

from heart_v2 import cli, config as C, guard, slurm as S  # noqa: E402
from lipid_library import general_policy, quality, ready  # noqa: E402


def _cli(args, monkeypatch, tmp_path):
    script = tmp_path / "fake_sbatch.py"
    script.write_text("import json,sys,os\nlog=os.environ['FAKE_LOG']\n"
                      "n=sum(1 for _ in open(log)) if os.path.exists(log) else 0\n"
                      "open(log,'a').write(json.dumps(sys.argv[1:])+'\\n')\nprint(3000000+n)\n")
    monkeypatch.setenv("HEART_V2_SBATCH_JSON", json.dumps([sys.executable, str(script)]))
    monkeypatch.setenv("FAKE_LOG", str(tmp_path / "calls.jsonl"))
    monkeypatch.setattr(cli, "_running_jobs", lambda names: [])
    out = []
    rc = cli.main(args, out=out.append)
    log = tmp_path / "calls.jsonl"
    return rc, "\n".join(out), [json.loads(l) for l in open(log)] if log.exists() else []


def _p(path):
    return str(path).replace("\\", "/")


def _flags(argv):
    return dict(a.split("=", 1) for a in argv if a.startswith("--") and "=" in a)


@pytest.fixture(scope="module")
def general_ok(tmp_path_factory):
    return h.write_general_dir(str(tmp_path_factory.mktemp("gen_ok")))


@pytest.fixture(scope="module")
def general_lumi(tmp_path_factory):
    """A general dataset with LUMI's OTHER convention (10 3D + 1 stored 2D = 11 slots)."""
    import lmdb

    from lipid_library.conformers import smi2coords_pretrain

    d = str(tmp_path_factory.mktemp("gen_lumi"))
    for split, smis in (("train", h.GENERAL_SMILES[:6]), ("valid", h.GENERAL_SMILES[6:])):
        env = lmdb.open(os.path.join(d, split + ".lmdb"), map_size=1 << 27, subdir=False)
        with env.begin(write=True) as txn:
            for i, smi in enumerate(smis):
                rec, _ = smi2coords_pretrain(smi, n_3d=10, store_2d=True)
                txn.put(str(i).encode(), pickle.dumps(rec, protocol=4))
        env.close()
    shutil.copyfile(h.DICT, os.path.join(d, "dict.txt"))
    return d


# --------------------------------------------------------------------------- P0-1 general policy
def test_general_policy_measures_the_real_files(general_ok, general_lumi, tmp_path):
    ok = general_policy.check(general_ok, 10, 0, 64, h.DICT)
    assert ok["compatible"], ok["problems"]
    assert ok["splits"]["train"]["dominant_profile"] == "10/0" and ok["lipid_dict_identical"]
    bad = general_policy.check(general_lumi, 10, 0, 64)
    assert not bad["compatible"] and any("11" in p for p in bad["problems"])
    assert general_policy.check(general_lumi, 10, 1, 64)["compatible"]      # it IS the 11/1 convention
    assert not general_policy.check(str(tmp_path / "missing"), 10, 0)["compatible"]
    other = tmp_path / "dict.txt"
    other.write_text("[PAD]\nC\n")
    assert not general_policy.check(general_ok, 10, 0, 64, str(other))["compatible"]


def test_stage04_submission_refused_when_general_policy_differs(general_lumi, tmp_path, monkeypatch):
    root = tmp_path / "root"
    rc, out, calls = _cli(["--set", "paths.lipid_root=" + _p(root), "--set", "paths.general_data=" + _p(general_lumi),
                           "--set", "paths.lipid_input=" + _p(h.DICT), "library", "--submit"], monkeypatch, tmp_path)
    assert rc == 2 and "stage 04 refused" in out and calls == []
    reports = [f for f in os.listdir(root / "jobs") if f.startswith("general_policy_check-")]
    assert len(reports) == 1 and not json.load(open(root / "jobs" / reports[0]))["compatible"]


def test_stage04_submission_refused_when_general_data_is_unreadable(tmp_path, monkeypatch):
    rc, out, calls = _cli(["--set", "paths.lipid_root=" + _p(tmp_path / "root"), "--set",
                           "paths.general_data=" + _p(tmp_path / "nowhere"), "--set", "paths.lipid_input=" + _p(h.DICT),
                           "library", "--submit"], monkeypatch, tmp_path)
    assert rc == 2 and "refused" in out and calls == []


def test_pool_job_itself_refuses_a_policy_mismatch(v2_library, general_lumi, tmp_path):
    import subprocess

    from conftest import find_bash

    env = {k: v for k, v in os.environ.items() if not k.startswith(("SLURM_", "HEART_", "LIPID_"))}
    env.update(HEART_SKIP_ENV="1", HEART_PYTHON=_posix(sys.executable), HEART_CONFIRM_LIPID="1",
               HEART_REPO=_posix(h.REPO_ROOT), LIPID_ROOT=_posix(v2_library), LIPID_DICT=_posix(h.DICT),
               STORE_2D="0", RECORDS_PER_SHARD="4", LIPID_WORKERS="2", HEART_DRY_RUN="1",
               HEART_DATA_PATH=_posix(general_lumi), PYTHONIOENCODING="utf-8")
    script = os.path.join(h.PRETRAIN_DIR, "scripts", "lipid_library", "04_conformers_pool.sh")
    res = subprocess.run([find_bash(), script], env=env, capture_output=True, text=True)
    assert res.returncode != 0 and "conformer policy does not match" in res.stderr


def _posix(p):
    p = str(p).replace("\\", "/")
    if sys.platform == "win32" and len(p) > 1 and p[1] == ":":
        p = "/" + p[0].lower() + p[2:]
    return p


# --------------------------------------------------------------------------- P0-2 shard integrity
def _lmdb_copy(v2_library, tmp_path):
    dst = str(tmp_path / "lmdb")
    shutil.copytree(os.path.join(v2_library, "lmdb"), dst)    # copytree keeps mtimes (copy2)
    return dst


def test_quick_check_detects_truncation_head_corruption_and_rewrites(v2_library, tmp_path):
    lmdb = _lmdb_copy(v2_library, tmp_path)
    assert ready.verify(lmdb)[1] == []
    shard = os.path.join(lmdb, "shard-00001", "train.lmdb")
    st = os.stat(shard)
    data = bytearray(open(shard, "rb").read())
    data[100] ^= 0xFF                                         # same size, same mtime, corrupted head block
    open(shard, "wb").write(bytes(data))
    os.utime(shard, ns=(st.st_atime_ns, st.st_mtime_ns))
    assert any("sampled content digest changed" in p for p in ready.verify(lmdb)[1])
    open(shard, "wb").write(bytes(data[:-4096]))             # truncated
    assert any("size" in p for p in ready.verify(lmdb)[1])


def test_unsampled_corruption_passes_quick_but_fails_full_verification(v2_library, tmp_path):
    """The documented limit of the quick check, and why a full verification is required."""
    lmdb = _lmdb_copy(v2_library, tmp_path)
    import unittest.mock as um

    with um.patch.object(ready, "BLOCK", 1024):                # tiny test shards: shrink the sampled blocks
        assert ready.write(lmdb)[1] == []
    table = json.load(open(os.path.join(lmdb, ready.INTEGRITY)))
    assert table["block_bytes"] == 1024
    e = table["shards"][0]
    path = os.path.join(lmdb, e["lmdb"])
    size, rel = e["size"], e["lmdb"]
    assert size > 8 * 1024
    sampled = set()
    for o in ready.sample_offsets(rel, size, 1024):
        sampled |= set(range(o, o + 1024))
    target = next(i for i in range(size) if i not in sampled)
    st = os.stat(path)
    data = bytearray(open(path, "rb").read())
    data[target] ^= 0xFF
    open(path, "wb").write(bytes(data))
    os.utime(path, ns=(st.st_atime_ns, st.st_mtime_ns))
    assert ready.verify(lmdb)[1] == []                        # not detectable by sampling
    rec, problems = ready.verify(lmdb, full=True, workers=2)
    assert rec is None and any("sha256 differs" in p for p in problems)
    assert json.load(open(os.path.join(lmdb, ready.VERIFIED)))["passed"] is False


def test_touched_shard_needs_full_verification_which_then_clears_it(v2_library, tmp_path):
    lmdb = _lmdb_copy(v2_library, tmp_path)
    shard = os.path.join(lmdb, "shard-00000", "train.lmdb")
    os.utime(shard, (time.time() + 10, time.time() + 10))      # e.g. copied/rsynced without -t
    assert any("run full verification" in p for p in ready.verify(lmdb)[1])
    rec, problems = ready.verify(lmdb, full=True, workers=2)
    assert problems == [] and json.load(open(os.path.join(lmdb, ready.VERIFIED)))["passed"]
    assert ready.verify(lmdb)[1] == []                        # integrity table refreshed after proof


def test_full_verification_age_limit(v2_library, tmp_path):
    lmdb = _lmdb_copy(v2_library, tmp_path)
    rec = json.load(open(os.path.join(lmdb, ready.READY)))
    assert rec["full_verification"]["source"].startswith("stage-05 finalize")
    assert ready.verify(lmdb, max_age_days=14)[1] == []
    rec["full_verification"]["epoch"] = time.time() - 30 * 86400
    json.dump(rec, open(os.path.join(lmdb, ready.READY), "w"))
    assert any("days old" in p for p in ready.verify(lmdb, max_age_days=14)[1])
    assert ready.verify(lmdb, full=True, workers=2)[1] == []
    assert ready.verify(lmdb, max_age_days=14)[1] == []


def test_continual_submission_requires_intact_shards(v2_library, tmp_path, monkeypatch):
    root = tmp_path / "libroot"
    os.makedirs(root)
    shutil.copytree(os.path.join(v2_library, "lmdb"), str(root / "lmdb"))
    ck = tmp_path / "ck.pt"
    ck.write_bytes(b"x")
    base = ["--set", "paths.lipid_root=" + _p(root), "--set", "paths.general_checkpoint=" + _p(ck),
            "--set", "paths.continual_output_root=" + _p(tmp_path / "runs")]
    rc, out, calls = _cli(base + ["continual", "--submit"], monkeypatch, tmp_path)
    assert rc == 0 and len(calls) == 1, out
    shard = root / "lmdb" / "shard-00002" / "train.lmdb"
    open(shard, "r+b").truncate(os.path.getsize(shard) - 1)
    rc, out, calls2 = _cli(base + ["continual", "--submit"], monkeypatch, tmp_path)
    assert rc == 2 and "not ready" in out and len(calls2) == 1        # nothing new submitted


# --------------------------------------------------------------------------- P1-3 configuration drift
def test_json_snapshot_round_trip_keeps_the_hash(tmp_path):
    cfg = C.load()[0]
    p = tmp_path / "snap.json"
    p.write_text(json.dumps(cfg, indent=2, sort_keys=True))
    assert C.config_hash(C._load_yaml(str(p))) == C.config_hash(cfg)    # 2e-05 must stay a float


def test_guard_fails_closed_on_configuration_drift(tmp_path, monkeypatch):
    cfg = C.load()[0]
    snap = tmp_path / "snap.json"
    snap.write_text(json.dumps(cfg, sort_keys=True))
    for k, v in {"SLURM_JOB_ID": "7", "HEART_V2_PROFILE": "lipid_01", "HEART_V2_CONFIG": str(snap),
                 "SLURM_CPUS_PER_TASK": "1", "SLURM_MEM_PER_NODE": "4096"}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.setenv("HEART_V2_CONFIG_SHA", C.config_hash(cfg))
    assert guard.main(["--profile", "lipid_01"]) == 0
    monkeypatch.setenv("HEART_V2_CONFIG_SHA", "0" * 64)
    assert guard.main(["--profile", "lipid_01"]) == 1
    monkeypatch.setenv("HEART_V2_CONFIG_SHA", C.config_hash(cfg))
    cfg["library"]["records_per_shard"] = 4999                 # snapshot edited after submission
    snap.write_text(json.dumps(cfg, sort_keys=True))
    assert guard.main(["--profile", "lipid_01"]) == 1
    monkeypatch.delenv("HEART_V2_CONFIG_SHA")
    assert guard.main(["--profile", "lipid_01"]) == 1


def test_tampered_snapshot_is_refused_at_submission(tmp_path, monkeypatch, general_ok):
    root = tmp_path / "root"
    args = ["--set", "paths.lipid_root=" + _p(root), "--set", "paths.general_data=" + _p(general_ok),
            "--set", "paths.lipid_input=" + _p(h.DICT), "library", "--submit"]
    rc, out, calls = _cli(args, monkeypatch, tmp_path)
    assert rc == 0, out
    snap = next(root.glob("jobs/heart_v2_config-*.json"))
    os.chmod(snap, 0o644)
    snap.write_text(snap.read_text().replace('"records_per_shard": 5000', '"records_per_shard": 4999'))
    n_before = len(calls)
    rc, out, calls = _cli(args, monkeypatch, tmp_path)         # same command again
    assert rc == 2 and "hashes to" in out and len(calls) == n_before


# --------------------------------------------------------------------------- P1-5 quality criteria
def test_quality_report_accounts_for_everything(v2_library):
    q = json.load(open(os.path.join(v2_library, "lmdb", "quality_report.json")))
    assert q["passed"] and q["criteria_enforced"] and q["failures"] == []
    e, s, v = q["enumeration"], q["stage04"], q["validation"]
    assert e["n_products"] + e["n_failures"] == e["n_combinations"] == 16
    assert s["n_records"] + s["n_skipped"] == s["n_input_rows"]
    assert set(s) >= {"skip_by_category", "skip_reasons", "conformer_attempts", "n_3d_success_hist",
                      "n_distinct_3d_hist", "records_with_2d_fill_fraction", "fill_2d_slot_fraction"}
    assert s["conformer_attempts"]["attempts"] >= 10 * s["n_records"]
    assert v["mode"] == "full" and v["coverage_fraction"] == 1.0 and v["n_fallback_audited"] == v["n_records_checked"]
    assert os.path.isfile(os.path.join(v2_library, "lmdb", "quality_report.md"))


def test_seed_start_0_gives_fewer_distinct_conformers_than_slots(v2_library):
    """LUMI-faithful seed_start=0: RDKit seeds 0 and 1 embed identically, so 10 slots hold <= 9
    distinct 3D conformers for most molecules. Measured and reported, not hidden."""
    s = json.load(open(os.path.join(v2_library, "lmdb", "quality_report.json")))["stage04"]
    assert s["slots_3d_per_record"] == 10
    assert s["mean_distinct_3d_per_record"] < 10
    assert s["fraction_records_with_all_slots_distinct"] < 0.5


def test_production_library_failing_a_criterion_gets_no_ready_receipt(v2_library, tmp_path):
    lmdb = _lmdb_copy(v2_library, tmp_path)
    for f in (ready.READY, ready.INTEGRITY):
        os.remove(os.path.join(lmdb, f))
    crit = tmp_path / "crit.json"
    crit.write_text(json.dumps({"max_skipped_fraction": -1.0}))     # any skipped fraction fails
    res = h.run_py(["-m", "lipid_library.quality", lmdb, "--enum-dir", os.path.join(v2_library, "enum"),
                    "--dedup-dir", os.path.join(v2_library, "dedup"), "--criteria-json", str(crit)], check=False)
    assert res.returncode == 1
    q = json.load(open(os.path.join(lmdb, "quality_report.json")))
    assert not q["passed"] and any("skipped fraction" in f for f in q["failures"])
    rec, problems = ready.write(lmdb)
    assert rec is None and any("quality criteria not met" in p for p in problems)


def test_quality_criteria_come_from_the_config():
    crit, source = quality.load_criteria()
    cfg = C.load()[0]
    assert crit == dict(quality.DEFAULT_CRITERIA, **cfg["library"]["quality"])
    assert source.endswith("heart_v2.yaml")


# --------------------------------------------------------------------------- P2-8 benchmark
def test_bench_dry_run_and_mocked_submission(tmp_path, monkeypatch):
    rc, out, calls = _cli(["--set", "paths.lipid_pilot_root=" + _p(tmp_path / "pilot"), "bench"], monkeypatch, tmp_path)
    assert rc == 0 and out.count("[DRY RUN]") == 6 and calls == []
    rc, out, _ = _cli(["bench", "--molecules", "200000"], monkeypatch, tmp_path)
    assert rc == 2 and "not a benchmark" in out
    rc, out, _ = _cli(["bench", "--workers", "300"], monkeypatch, tmp_path)
    assert rc == 2


def test_bench_report_compares_worker_counts(tmp_path):
    from lipid_library import bench_report

    dirs = []
    for w, hours in ((64, 1.0), (128, 0.55), (250, 0.40)):
        d = tmp_path / "w{}".format(w)
        d.mkdir()
        (d / "stage04_run-1.json").write_text(json.dumps({"workers": w, "molecules_written": 15000,
                                                           "elapsed_hours": hours, "written": 750, "failed": [],
                                                           "measured_sec_per_molecule_cpu": 15.0 * w * hours / 15000 * 240,
                                                           "all_complete": True}))
        dirs.append(str(d))
    rows = bench_report.compare(dirs)
    assert [r["workers"] for r in rows] == [64, 128, 250]
    assert rows[0]["parallel_efficiency"] == 1.0 and rows[2]["parallel_efficiency"] < rows[1]["parallel_efficiency"] < 1
    assert rows[2]["best"]
    assert bench_report.main(dirs) == 0


# --------------------------------------------------------------------------- P2-9 GPU type detection
SCONTROL_TYPED = ("JobId=1 JobName=x\n   TRES=cpu=16,mem=200G,node=1,billing=16,gres/gpu=1,gres/gpu:h200=1\n"
                  "   TresPerNode=gres/gpu:h200:1\n     Nodes=cmri-gpu04 CPU_IDs=0-15 Mem=204800 GRES=gpu:h200:1(IDX:0)\n")
SCONTROL_T4 = "   AllocTRES=cpu=16,gres/gpu=1,gres/gpu:t4=1\n   TresPerNode=gres/gpu:t4:1\n"
SCONTROL_UNTYPED = "   AllocTRES=cpu=16,mem=200G,gres/gpu=1\n   TresPerNode=gres/gpu:1\n"


def _fake(scontrol="", smi=""):
    return lambda argv: scontrol if argv[0] == "scontrol" else smi


@pytest.mark.parametrize("scontrol, smi, ok", [
    (SCONTROL_TYPED, "", True),
    (SCONTROL_TYPED, "NVIDIA H200\n", True),
    (SCONTROL_UNTYPED, "NVIDIA H200\n", True),
    (SCONTROL_UNTYPED, "NVIDIA H200 NVL\n", True),
    (SCONTROL_T4, "", False),
    (SCONTROL_UNTYPED, "Tesla T4\n", False),
    (SCONTROL_TYPED, "Tesla T4\n", False),
    (SCONTROL_UNTYPED, "", False),                             # unverifiable -> fail closed
    ("   TresPerNode=gres/gpu:h200a:1\n", "", False),
])
def test_gpu_type_detection(scontrol, smi, ok):
    ev = S.gpu_type_evidence({"SLURM_JOB_ID": "1"}, run=_fake(scontrol, smi))
    problems = S.check_gpu_type("gpu:h200:1", ev)
    assert (problems == []) == ok, (ev, problems)


def test_allocation_check_uses_the_detected_gpu_type():
    cfg = C.load()[0]
    env = {"SLURM_JOB_ID": "1", "SLURM_CPUS_PER_TASK": "16", "SLURM_MEM_PER_NODE": "204800",
           "SLURM_GPUS_ON_NODE": "1", "SLURM_JOB_PARTITION": "gpu"}
    assert S.check_allocation(cfg, "continual", env, run=_fake(SCONTROL_TYPED, "NVIDIA H200")) == []
    assert S.check_allocation(cfg, "continual", env, run=_fake(SCONTROL_T4, "Tesla T4"))
    no_gpu = dict(env)
    no_gpu.pop("SLURM_GPUS_ON_NODE")
    assert any("no GPU was allocated" in p for p in S.check_allocation(cfg, "continual", no_gpu,
                                                                       run=_fake(SCONTROL_TYPED)))
    assert S.check_allocation(cfg, "continual", dict(env, HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE="1"),
                              run=_fake()) == []
