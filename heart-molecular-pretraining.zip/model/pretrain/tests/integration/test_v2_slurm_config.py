"""HEART v2: one SLURM source of truth, mocked sbatch, refusal of wrong resources.

The ACTUAL sbatch argv produced by bin/heart is captured by a fake sbatch
(HEART_V2_SBATCH_JSON) and inspected flag by flag. Nothing is submitted.
"""
import json
import os
import re
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import v2_helpers as h  # noqa: E402

from heart_v2 import cli, config as C, slurm as S  # noqa: E402

FAKE_SBATCH = r'''
import json, os, sys
log = os.environ["FAKE_SBATCH_LOG"]
n = sum(1 for _ in open(log)) if os.path.exists(log) else 0
with open(log, "a") as fh:
    fh.write(json.dumps(sys.argv[1:]) + "\n")
print(str(1013400 + n))
'''


def _flags(argv):
    out = {}
    for a in argv[1:]:
        if a.startswith("--") and "=" in a:
            k, v = a.split("=", 1)
            out[k] = v
    return out


def _export(argv):
    exp = next(a for a in argv if a.startswith("--export="))[len("--export="):]
    return dict(kv.split("=", 1) for kv in exp.split(",")[1:])


@pytest.fixture()
def fake_sbatch(tmp_path, monkeypatch):
    script = tmp_path / "fake_sbatch.py"
    script.write_text(FAKE_SBATCH)
    log = tmp_path / "sbatch_calls.jsonl"
    monkeypatch.setenv("HEART_V2_SBATCH_JSON", json.dumps([sys.executable, str(script)]))
    monkeypatch.setenv("FAKE_SBATCH_LOG", str(log))
    monkeypatch.setattr(cli, "_running_jobs", lambda names: [])

    def calls():
        return [json.loads(l) for l in log.read_text().splitlines()] if log.exists() else []
    return calls


def _run(args):
    lines = []
    rc = cli.main(args, out=lines.append)
    return rc, "\n".join(lines)


# --------------------------------------------------------------------------- one source of truth
def test_config_is_valid_and_every_sbatch_header_equals_its_profile():
    cfg, _, _ = C.load()
    for name in cfg["slurm"]["profiles"]:
        assert S.header_mismatches(cfg, name) == [], name


def test_no_other_lipid_or_continual_script_declares_resources():
    """Superseded v1 launchers carry no #SBATCH lines (no competing source)."""
    cfg, _, _ = C.load()
    owned = {S.script_path(cfg, n) for n in cfg["slurm"]["profiles"]}
    d = os.path.join(h.PRETRAIN_DIR, "scripts", "lipid_library")
    for f in os.listdir(d):
        p = os.path.join(d, f).replace("\\", "/")
        if p in owned:
            continue
        text = open(p, encoding="utf-8").read()
        assert not re.search(r"^#SBATCH", text, re.M), f                    # no directive lines
        assert not re.search(r"^\s*sbatch\s", text, re.M), f


def test_stage04_and_continual_profiles_are_the_two_h200_profiles():
    cfg, _, _ = C.load()
    f04 = _flags(S.render(cfg, "lipid_04"))
    assert f04["--gres"] == "gpu:h200:1" and f04["--cpus-per-task"] == "250" and f04["--mem"] == "500G"
    assert f04["--nodelist"] == "cmri-gpu04" and f04["--time"] == "2-00:00:00" and f04["--partition"] == "gpu"
    fc = _flags(S.render(cfg, "continual"))
    assert fc["--gres"] == "gpu:h200:1" and fc["--cpus-per-task"] == "16" and fc["--mem"] == "200G"
    assert fc["--partition"] == "gpu" and "--nodelist" not in fc
    for name in ("lipid_01", "lipid_02", "lipid_03", "lipid_03b", "lipid_05"):
        f = _flags(S.render(cfg, name))
        assert "--gres" not in f, name                          # CPU stages never reserve an H200
        assert int(f["--cpus-per-task"]) <= 16, name


@pytest.mark.parametrize("override, msg", [
    ("slurm.profiles.lipid_04.gres=gpu:1", "gpu:h200"),
    ("slurm.profiles.lipid_04.gres=gpu:h200a:1", "gpu:h200"),
    ("slurm.profiles.lipid_04.gres=gpu:t4:1", "gpu:h200"),
    ("slurm.profiles.lipid_04.nodelist=cmri-t4-01", "T4"),
    ("slurm.profiles.continual.gres=gpu:t4:1", "gpu:h200"),
    ("slurm.profiles.continual.cpus_per_task=250", "16 CPUs / 200G"),
    ("slurm.profiles.continual.mem=500G", "16 CPUs / 200G"),
    ("slurm.profiles.lipid_02.gres=gpu:h200:1", "must not request a GPU"),
    ("slurm.profiles.lipid_02.array=0-99", "enum_array_size"),
    ("library.stage04_workers=300", "stage04_workers"),
    ("continual.num_workers=16", "num_workers"),
    ("paths.continual_output_root=/x/runs/h200/full", "general H200 run tree"),
])
def test_contradictory_or_wrong_resources_are_refused(override, msg):
    with pytest.raises(C.ConfigError, match=re.escape(msg)):
        C.load(overrides=[override])
    rc, out = _run(["--set", override, "library", "--dry-run"])
    assert rc == 2 and "REFUSED" in out


def test_runtime_guard_detects_a_wrong_allocation():
    cfg, _, _ = C.load()
    ok = {"SLURM_CPUS_PER_TASK": "250", "SLURM_MEM_PER_NODE": "512000", "SLURM_JOB_PARTITION": "gpu",
          "SLURM_GPUS_ON_NODE": "1", "SLURMD_NODENAME": "cmri-gpu04"}
    assert S.check_allocation(cfg, "lipid_04", ok) == []
    assert S.check_allocation(cfg, "lipid_04", dict(ok, SLURM_CPUS_PER_TASK="16"))
    assert S.check_allocation(cfg, "lipid_04", dict(ok, SLURMD_NODENAME="cmri-gpu01"))
    assert S.check_allocation(cfg, "continual", dict(ok, SLURM_MEM_PER_NODE="204800",
                                                     SLURMD_NODENAME="cmri-gpu05"))  # 250 CPUs != 16
    assert S.check_allocation(cfg, "continual", {"SLURM_CPUS_PER_TASK": "16", "SLURM_MEM_PER_NODE": "204800",
                                                 "SLURM_GPUS_ON_NODE": "1"}) == []
    assert S.check_allocation(cfg, "lipid_02", {"SLURM_CPUS_PER_TASK": "1", "SLURM_MEM_PER_NODE": "4096",
                                                "SLURM_GPUS_ON_NODE": "1"})       # CPU stage got a GPU


def test_guard_refuses_hand_submitted_jobs(monkeypatch):
    from heart_v2 import guard

    monkeypatch.setenv("SLURM_JOB_ID", "1")
    monkeypatch.delenv("HEART_V2_PROFILE", raising=False)
    monkeypatch.delenv("HEART_V2_ALLOW_DIRECT", raising=False)
    assert guard.main(["--profile", "lipid_04"]) == 1
    monkeypatch.setenv("HEART_V2_PROFILE", "continual")
    assert guard.main(["--profile", "lipid_04"]) == 1             # submitted as another profile
    monkeypatch.setenv("HEART_V2_PROFILE", "lipid_04")
    monkeypatch.setenv("SLURM_CPUS_PER_TASK", "250")
    monkeypatch.setenv("SLURM_MEM_PER_NODE", "512000")
    monkeypatch.setenv("SLURM_GPUS_ON_NODE", "1")
    assert guard.main(["--profile", "lipid_04"]) == 1             # v2 hardening: no HEART_V2_CONFIG_SHA
    monkeypatch.setenv("HEART_V2_CONFIG_SHA", C.config_hash(C.load()[0]))
    monkeypatch.setenv("HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE", "1")  # no scontrol/nvidia-smi here
    assert guard.main(["--profile", "lipid_04"]) == 0


# --------------------------------------------------------------------------- mocked submission
@pytest.fixture(scope="module")
def general_ok(tmp_path_factory):
    """General-format stand-in with the audited policy (10 stored 3D slots, STORE_2D=0)."""
    return h.write_general_dir(str(tmp_path_factory.mktemp("general_ok"))).replace("\\", "/")


def test_full_library_submission_chain_with_mocked_sbatch(tmp_path, fake_sbatch, general_ok):
    root = str(tmp_path / "lipid_root")
    sheet = tmp_path / "sheet.xlsx"
    sheet.write_bytes(b"placeholder")
    rc, out = _run(["--set", "paths.lipid_root=" + root.replace("\\", "/"), "--set",
                    "paths.lipid_input=" + str(sheet).replace("\\", "/"), "--set",
                    "paths.general_data=" + general_ok, "library", "--submit"])
    assert "general ligand slot policy" in out and "COMPATIBLE" in out
    assert rc == 0, out
    calls = fake_sbatch()
    assert len(calls) == 6
    labels = ["lipid-01-bb", "lipid-02-enum", "lipid-03-dedup", "lipid-03b-part", "lipid-04-pool", "lipid-05-final"]
    ids = [str(1013400 + i) for i in range(6)]
    for i, (argv, label) in enumerate(zip(calls, labels)):
        f = _flags(["sbatch"] + argv)
        assert f["--job-name"] == label
        assert f["--partition"] == "gpu"
        dep = f.get("--dependency")
        if i == 0:
            assert dep is None
        elif i == 5:
            assert dep == "afterany:" + ids[4]                 # 05 runs after an incomplete 04 and fails closed
        else:
            assert dep == "afterok:" + ids[i - 1]
        env = _export(["sbatch"] + argv)
        assert env["HEART_V2_PROFILE"] == "lipid_0" + ["1", "2", "3", "3b", "4", "5"][i]
        assert env["STORE_2D"] == "0" and env["LIPID_ROOT"] == root.replace("\\", "/")
        assert env["HEART_REPO"] == h.REPO_ROOT.replace("\\", "/")      # the v2 checkout, not the old clone
        assert env["HEART_CONFIRM_LIPID"] == "1"
    f04 = _flags(["sbatch"] + calls[4])
    assert (f04["--gres"], f04["--cpus-per-task"], f04["--mem"], f04["--nodelist"]) == (
        "gpu:h200:1", "250", "500G", "cmri-gpu04")
    assert _export(["sbatch"] + calls[4])["LIPID_WORKERS"] == "250"
    assert _flags(["sbatch"] + calls[1])["--array"] == "0-63"
    rec = [json.loads(l) for l in open(os.path.join(root, "jobs", "submissions.jsonl"))]
    assert [r["job_id"] for r in rec] == ids
    snap = _export(["sbatch"] + calls[0])["HEART_V2_CONFIG"]
    assert os.path.isfile(snap)                               # the jobs read the frozen effective config
    assert C.config_hash(C._load_yaml(snap)) == _export(["sbatch"] + calls[0])["HEART_V2_CONFIG_SHA"]
    assert not os.access(snap, os.W_OK)                       # read-only snapshot
    assert len([f for f in os.listdir(os.path.join(root, "jobs")) if f.startswith("general_policy_check-")]) == 1


def test_dry_run_submits_nothing_and_existing_outputs_need_resume(tmp_path, fake_sbatch):
    root = tmp_path / "lipid_root"
    rc, out = _run(["--set", "paths.lipid_root=" + str(root).replace("\\", "/"), "library"])
    assert rc == 0 and out.count("[DRY RUN]") == 6 and fake_sbatch() == []
    assert not root.exists()
    (root / "bb").mkdir(parents=True)
    (root / "bb" / "building_blocks.csv").write_text("x")
    (root / "bb" / "summary.json").write_text(json.dumps({"n_combinations": 16}))
    rc, out = _run(["--set", "paths.lipid_root=" + str(root).replace("\\", "/"), "library"])
    assert rc == 2 and "--resume" in out


def test_resume_resubmits_only_failed_enumeration_tasks(tmp_path, fake_sbatch, general_ok):
    """Stage-02 task 63 failed: only --array=63 and the downstream stages are resubmitted."""
    root = tmp_path / "lipid_root"
    (root / "bb").mkdir(parents=True)
    (root / "bb" / "building_blocks.csv").write_text("x")
    (root / "bb" / "summary.json").write_text(json.dumps({"n_combinations": 15241216}))
    prod = root / "enum" / "products"
    prod.mkdir(parents=True)
    fp = "f" * 64
    (root / "enum" / "enumeration_config.json").write_text(json.dumps(
        {"fingerprint": fp, "config": {"range": [0, 15241216], "chunk_size": 50000}}))
    for ci in range(305):
        if ci % 64 == 63:
            continue                                        # task 63's chunks 63, 127, 191, 255 missing
        lo, hi = ci * 50000, min((ci + 1) * 50000, 15241216)
        (prod / "products-{}-{}.done.json".format(lo, hi)).write_text(json.dumps({"config_fingerprint": fp}))
        (prod / "products-{}-{}.csv.gz".format(lo, hi)).write_text("")
    rc, out = _run(["--set", "paths.lipid_root=" + str(root).replace("\\", "/"), "library", "--status"])
    assert "301/305 chunks" in out and "--array=63" in out
    rc, out = _run(["--set", "paths.lipid_root=" + str(root).replace("\\", "/"), "--set",
                    "paths.general_data=" + general_ok, "library", "--resume", "--submit"])
    assert rc == 0, out
    calls = fake_sbatch()
    assert [_flags(["sbatch"] + c)["--job-name"] for c in calls] == [
        "lipid-02-enum", "lipid-03-dedup", "lipid-03b-part", "lipid-04-pool", "lipid-05-final"]
    assert _flags(["sbatch"] + calls[0])["--array"] == "63"
    assert _export(["sbatch"] + calls[0])["LIPID_ENUM_ARRAY_SIZE"] == "64"   # stride kept: same chunk mapping
    assert "%A_%a" in _flags(["sbatch"] + calls[0])["--output"]


def test_continual_submission_is_gated_on_a_ready_library(tmp_path, fake_sbatch):
    root = str(tmp_path / "lipid_root").replace("\\", "/")
    rc, out = _run(["--set", "paths.lipid_root=" + root, "continual", "--submit"])
    assert rc == 2 and "not ready" in out and fake_sbatch() == []
