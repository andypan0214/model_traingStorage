"""Shared fixtures for the HEART v2 integration tests (tiny synthetic data only).

Imported explicitly by the test modules (`from v2_fixtures import v2_library`) instead of
a second conftest.py, so `from conftest import ...` in the existing tests stays unambiguous.
"""
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import v2_helpers as h  # noqa: E402


@pytest.fixture(scope="session")
def v2_library(tmp_path_factory):
    """One production-shaped tiny library shared by the read-only tests."""
    pytest.importorskip("rdkit")
    pytest.importorskip("lmdb")
    root = str(tmp_path_factory.mktemp("v2lib"))
    h.build_library(root)
    return root
