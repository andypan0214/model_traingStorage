"""HEART v2: the completed general pretraining is frozen byte for byte (upstream 73a5f9d)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import v2_helpers  # noqa: E402,F401  (puts model/pretrain on sys.path)

from heart_v2 import baseline  # noqa: E402

MUST_BE_PROTECTED = [
    "model/pretrain/scripts/pretrain_heart-h200.sh",
    "model/pretrain/scripts/heart_lib.sh",
    "model/pretrain/scripts/pretrain_heart.sh",
    "model/pretrain/scripts/pretrain_smoke.sh",
    "model/pretrain/configs/full_pretrain.yaml",
    "model/pretrain/configs/pilot.yaml",
    "model/pretrain/tools/check_resume_args.py",
    "model/pretrain/tools/verify_checkpoint.py",
    "model/unimol/tasks/unimol_contrastive.py",
    "model/unimol/models/unimol_contrastive.py",
    "model/unimol/models/transformer_encoder_with_pair.py",
    "model/unimol/losses/unimol_contrastive.py",
    "model/unimol/data/add_2d_conformer_dataset.py",
    "model/unimol/data/lmdb_dataset.py",
    "model/pretrain/tests/fixtures/dict.txt",
    "model/HEART_H200_checkpoint_best_embedding_evaluation.ipynb",
    "model/HEART_best_checkpoint_embedding_evaluation.ipynb",
    "model/unimol/LICENSE.Uni-Mol",
    "model/unimol/LICENSE.LUMI-lab",
    "model/unimol/THIRD_PARTY_NOTICES.md",
]


def test_general_files_are_in_the_protected_manifest():
    import json

    m = json.load(open(baseline.MANIFEST))
    assert m["upstream_sha"] == baseline.UPSTREAM_SHA
    for p in MUST_BE_PROTECTED:
        assert p in m["protected"], p
        assert not baseline.is_modifiable(p), p


def test_protected_files_are_byte_identical_to_upstream():
    r = baseline.verify()
    assert r["pass"], r
    assert r["n_protected"] >= len(MUST_BE_PROTECTED)
    assert not r["modified"]
    assert all(p in __import__('json').load(open(baseline.MANIFEST)).get('approved_path_migrations', {})
               for p in r.get('path_migrated', []))


def test_git_diff_against_upstream_touches_only_modifiable_or_new_files():
    changes = baseline.git_diff_names()
    if changes is None:
        import pytest

        pytest.skip("git history of the pinned upstream commit not available")
    import json

    protected = json.load(open(baseline.MANIFEST))["protected"]
    approved = set(json.load(open(baseline.MANIFEST)).get("approved_path_migrations", {}))
    bad = [(s, p) for s, p in changes if p in protected and p not in approved]
    # Approved exceptions are hash-pinned by baseline.verify(); other changes are forbidden.
    assert bad == [], bad
