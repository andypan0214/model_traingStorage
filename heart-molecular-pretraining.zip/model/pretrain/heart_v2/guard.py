"""Start-of-job guard: the real SLURM allocation must be the configured profile.

    python -m heart_v2.guard --profile lipid_04      (called by the job scripts)

Outside SLURM it only validates the configuration. Inside SLURM it compares
SLURM_CPUS_PER_TASK / SLURM_MEM_PER_NODE / partition / GPUs / node with the
profile in config/heart_v2.yaml and exits 1 on any difference, so a job that
was submitted by hand with other flags (or whose #SBATCH header drifted)
stops before doing work. Jobs not submitted through bin/heart are refused
unless HEART_V2_ALLOW_DIRECT=1 (then they are still checked). A bin/heart job whose
configuration hash differs from the submitted HEART_V2_CONFIG_SHA is refused (fail closed).
"""
import argparse
import os
import sys

from . import config as cfgmod
from .slurm import check_allocation


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--profile", required=True)
    ap.add_argument("--config", default=None)
    ns = ap.parse_args(argv)
    try:
        cfg, path, warnings = cfgmod.load(ns.config)
    except cfgmod.ConfigError as exc:
        print("HEART v2 guard: configuration error: {}".format(exc), file=sys.stderr)
        return 1
    for w in warnings:
        print("HEART v2 guard: WARNING: {}".format(w), file=sys.stderr)
    env = os.environ
    print("HEART v2 guard: profile {} from {} (sha256 {})".format(ns.profile, path, cfgmod.config_hash(cfg)[:16]))
    if not env.get("SLURM_JOB_ID"):
        print("HEART v2 guard: not under SLURM; allocation not checked")
        return 0
    submitted = env.get("HEART_V2_PROFILE")
    if submitted is None and env.get("HEART_V2_ALLOW_DIRECT") != "1":
        print("HEART v2 guard: this job was not submitted by bin/heart (no HEART_V2_PROFILE). Submit with "
              "`bin/heart library|continual ... --submit`, or set HEART_V2_ALLOW_DIRECT=1 to run a "
              "hand-submitted job that matches the profile.", file=sys.stderr)
        return 1
    if submitted is not None and submitted != ns.profile:
        print("HEART v2 guard: submitted as profile {} but this script is {}".format(submitted, ns.profile),
              file=sys.stderr)
        return 1
    # v2 hardening: configuration drift between submission and job start FAILS (no override).
    # bin/heart exports the hash of the frozen snapshot it wrote; the job reloads that snapshot.
    want_sha = env.get("HEART_V2_CONFIG_SHA")
    have_sha = cfgmod.config_hash(cfg)
    if submitted is not None:
        if not want_sha:
            print("HEART v2 guard: HEART_V2_CONFIG_SHA missing from a bin/heart submission", file=sys.stderr)
            return 1
        if want_sha != have_sha:
            print("HEART v2 guard: CONFIGURATION DRIFT: submitted with {} but {} now hashes to {} -- refusing "
                  "to run; resubmit with bin/heart".format(want_sha[:16], path, have_sha[:16]), file=sys.stderr)
            return 1
        print("HEART v2 guard: configuration {} matches the submission".format(have_sha[:16]))
    problems = check_allocation(cfg, ns.profile, env)
    for p in problems:
        print("HEART v2 guard: ALLOCATION MISMATCH: {}".format(p), file=sys.stderr)
    if problems:
        return 1
    print("HEART v2 guard: allocation matches profile {}".format(ns.profile))
    return 0


if __name__ == "__main__":
    sys.exit(main())
