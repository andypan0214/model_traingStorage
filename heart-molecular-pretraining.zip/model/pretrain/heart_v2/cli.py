"""bin/heart: safe-by-default orchestration of the lipid library and continual training.

    bin/heart check                              config, #SBATCH headers, frozen-baseline hashes, paths
    bin/heart render <profile>                   the exact sbatch flags of one profile
    bin/heart baseline                           protected general files vs upstream 73a5f9d
    bin/heart library --status                   progress from receipts (read-only)
    bin/heart library [--dry-run]                preview the full 01->05 chain (default; submits nothing)
    bin/heart library --resume [--dry-run]       preview ONLY the missing work + dependencies
    bin/heart library [--resume] --submit        submit (explicit); job ids -> <lipid_root>/jobs/
    bin/heart library --pilot 100 [--submit]     isolated pilot: 03b/04/05 of the first N products
    bin/heart continual --check                  read-only preflight on the login node (runner HEART_DRY_RUN=1)
    bin/heart continual [--dry-run]              print the 1-H200 / 16-CPU / 200G continual sbatch command
    bin/heart continual --smoke --submit         isolated smoke run (separate run name/output)
    bin/heart continual --submit                 start, or resume, the production continual run
    bin/heart evaluate --check [--run-dir D]     read-only checkpoint comparison general vs continual
    bin/heart library --verify-full [--submit]   full sha256 of every shard as a CPU job (lipid_verify)
    bin/heart bench [--submit]                   stage-04 scaling benchmark, 64/128/250 workers (isolated)

Global: --config FILE (or HEART_V2_CONFIG), --set key.path=value (repeatable), --json.
Nothing is ever submitted without --submit. Library completion never submits training.
"""
import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys

from . import V2_VERSION, baseline, config as C, slurm as S, status as ST

LIB_STAGE_PROFILE = {"01": "lipid_01", "02": "lipid_02", "03": "lipid_03", "03b": "lipid_03b",
                     "04": "lipid_04", "05": "lipid_05"}
# Values hard-coded in the job scripts; the config must agree (it cannot change them).
FIXED_LIBRARY = {"n_3d": 10, "max_try": 15, "max_iterations": 4000}
FIXED_CONTINUAL = {"lr": 2e-5, "warmup_updates": 1000, "weight_decay": 1e-4}


class Refused(RuntimeError):
    pass


# --------------------------------------------------------------------------- helpers
def _git_sha():
    try:
        return subprocess.run(["git", "-C", C.REPO_ROOT, "rev-parse", "HEAD"], capture_output=True,
                              text=True, check=True).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def _fixed_checks(cfg):
    problems = []
    for k, v in FIXED_LIBRARY.items():
        if cfg["library"][k] != v:
            problems.append("library.{}={} but the stage scripts hard-code {}".format(k, cfg["library"][k], v))
    for k, v in FIXED_CONTINUAL.items():
        if abs(float(cfg["continual"][k]) - v) > 1e-12:
            problems.append("continual.{}={} but the runner hard-codes {} (LUMI continual)".format(
                k, cfg["continual"][k], v))
    return problems


def common_env(cfg, cfg_path, cfg_sha, profile_name):
    p, e = cfg["paths"], cfg["environment"]
    return {"HEART_V2_PROFILE": profile_name, "HEART_V2_CONFIG": cfg_path, "HEART_V2_CONFIG_SHA": cfg_sha,
            "HEART_REPO": C.REPO_ROOT.replace("\\", "/"), "HEART_DATA_PATH": p["general_data"],
            "HEART_UNICORE_SRC": p["unicore_src"], "HEART_CONDA_ENV": e["conda_env"],
            "HEART_CONDA_MODULE": e["conda_module"], "HEART_CONDA_SH": e["conda_sh"]}


def library_env(cfg, root, lmdb_dir=None, limit=None, records_per_shard=None):
    lib, p = cfg["library"], cfg["paths"]
    env = {"HEART_CONFIRM_LIPID": "1", "LIPID_ROOT": root, "LIPID_INPUT": p["lipid_input"],
           "STORE_2D": str(lib["store_2d"]), "RECORDS_PER_SHARD": str(records_per_shard or lib["records_per_shard"]),
           "SEED_START": str(lib["seed_start"]), "MAX_ATOMS": str(lib["max_atoms"]),
           "CHUNK_SIZE": str(lib["chunk_size"]), "LIPID_ENUM_ARRAY_SIZE": str(lib["enum_array_size"]),
           "LIPID_ARRAY_SIZE": str(lib["stage04_stride"]), "LIPID_WORKERS": str(lib["stage04_workers"]),
           "LIPID_STAGE05_WORKERS": str(lib["stage05_workers"]), "VALID_FRACTION": str(lib["valid_fraction"]),
           "SPLIT_SEED": str(lib["split_seed"]), "VALIDATE_SAMPLE": str(lib["validate_sample_per_shard"]),
           "LIPID_DEADLINE_MARGIN_MIN": str(lib["stage04_deadline_margin_min"]),
           "LIPID_BYTES_PER_RECORD": str(lib["stage04_bytes_per_record_assumed"]),
           "LIPID_MIN_FREE_FACTOR": str(lib["stage04_min_free_disk_factor"])}
    if lmdb_dir:
        env["LIPID_LMDB_DIR"] = lmdb_dir
    if limit:
        env["LIMIT"] = str(limit)
    return env


def _running_jobs(job_names):
    """[(id, name, state)] of this user's queued/running jobs with one of these names."""
    if not shutil.which("squeue"):
        return []
    try:
        out = subprocess.run(["squeue", "-h", "-u", os.environ.get("USER", ""), "-o", "%i|%j|%T"],
                             capture_output=True, text=True, timeout=60).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    rows = [line.split("|") for line in out.splitlines() if line.count("|") == 2]
    return [r for r in rows if r[1] in job_names]


def _sbatch_prefix():
    """["sbatch"], or the test stand-in from HEART_V2_SBATCH_JSON (mocked-SLURM tests only)."""
    override = os.environ.get("HEART_V2_SBATCH_JSON")
    return json.loads(override) if override else ["sbatch"]


def _have_sbatch():
    return bool(os.environ.get("HEART_V2_SBATCH_JSON")) or shutil.which("sbatch") is not None


class Submitter:
    """Dry-run printer or real sbatch caller; records every submission."""

    def __init__(self, cfg, cfg_path, cfg_sha, submit, jobs_dir, out=print):
        self.cfg, self.cfg_path, self.cfg_sha = cfg, cfg_path, cfg_sha
        self.submit, self.jobs_dir, self.out = submit, jobs_dir, out
        self.records = []

    def snapshot(self):
        """The effective configuration (incl. --set) is frozen to a file the jobs read."""
        path = os.path.join(self.jobs_dir, "heart_v2_config-{}.json".format(self.cfg_sha[:12])).replace("\\", "/")
        if self.submit:
            os.makedirs(self.jobs_dir, exist_ok=True)
            if not os.path.isfile(path):
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
                    json.dump(self.cfg, fh, indent=2, sort_keys=True)
                os.replace(tmp, path)
                os.chmod(path, 0o444)                    # jobs read it; nobody should edit it
            # v2 hardening: the jobs refuse to run if this file does not hash to cfg_sha
            on_disk = C.config_hash(C._load_yaml(path))
            if on_disk != self.cfg_sha:
                raise Refused("config snapshot {} hashes to {} != {} (edited?): delete it or change the "
                              "config".format(path, on_disk[:16], self.cfg_sha[:16]))
        return path

    def run(self, label, profile_name, env, dependency=None, array=None, lipid_root=None):
        argv = S.render(self.cfg, profile_name, export=env, dependency=dependency, array=array,
                        lipid_root=lipid_root)
        if not self.submit:
            self.out("[DRY RUN] {:<9} {}".format(label, S.shell_join(argv)))
            job = "<JOB_{}>".format(label)
        else:
            for flag in ("--output", "--error"):
                val = next(a.split("=", 1)[1] for a in argv if a.startswith(flag + "="))
                os.makedirs(os.path.dirname(val), exist_ok=True)       # SLURM needs the log dir to exist
            res = subprocess.run(_sbatch_prefix() + argv[1:], capture_output=True, text=True)
            if res.returncode != 0:
                raise Refused("sbatch failed for {} (exit {}): {}".format(label, res.returncode, res.stderr.strip()))
            job = res.stdout.strip().split(";")[0]
            if not job.isdigit():
                raise Refused("unexpected sbatch output for {}: {!r}".format(label, res.stdout))
            self.out("SUBMITTED {:<9} job {}  {}".format(label, job, S.shell_join(argv)))
        rec = {"time": datetime.datetime.now().isoformat(timespec="seconds"), "label": label,
               "profile": profile_name, "job_id": job, "dependency": dependency, "array": array,
               "argv": argv, "config_sha256": self.cfg_sha, "git_sha": _git_sha(), "submitted": self.submit,
               "orchestrator": V2_VERSION}
        self.records.append(rec)
        if self.submit:
            os.makedirs(self.jobs_dir, exist_ok=True)
            with open(os.path.join(self.jobs_dir, "submissions.jsonl"), "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec) + "\n")
        return job


# --------------------------------------------------------------------------- library
def plan_library(status, resume, pilot, from_stage=None):
    """[(stage, array or None)] to submit, in order."""
    if pilot:
        if status["stages"]["03"]["state"] != "done":
            raise Refused("a pilot reuses the production enumeration + dedup: stage 03 must be done first")
        stages = ["03b", "04", "05"]
        if resume and status["next"] in stages:
            stages = stages[stages.index(status["next"]):]
        elif resume and status["next"] is None:
            return []
        return [(s, None) for s in stages]
    if from_stage:
        if from_stage not in ST.STAGES:
            raise Refused("--from-stage must be one of {}".format(ST.STAGES))
        return [(s, None) for s in ST.STAGES[ST.STAGES.index(from_stage):]]
    if not resume:
        if any(status["stages"][s]["state"] != "missing" for s in ST.STAGES):
            raise Refused("outputs already exist under {}: use --resume (finished work is kept and skipped)"
                          .format(status["root"]))
        return [(s, None) for s in ST.STAGES]
    failed = [s for s in ST.STAGES if status["stages"][s]["state"] == "failed" and s != "05"]
    if failed:
        raise Refused("stage(s) {} have outputs from another configuration or inconsistent receipts: "
                      "inspect `bin/heart library --status`; never mix configurations in one root".format(failed))
    nxt = status["next"]
    if nxt is None:
        return []
    plan = []
    for s in ST.STAGES[ST.STAGES.index(nxt):]:
        array = None
        if s == "02" and status["stages"]["02"].get("state") == "partial":
            array = ",".join(str(t) for t in status["stages"]["02"]["resubmit_array_tasks"])
        plan.append((s, array))
    return plan


def general_policy_gate(cfg, submit, jobs_dir, pilot, out=print):
    """Mandatory read-only measurement of the REAL general ligand slot policy before stage 04.

    Production submission (any plan containing stage 04, not a pilot): refuses unless the general
    train/valid LMDBs are readable AND match library.n_3d / library.store_2d. The report is saved
    under <lipid_root>/jobs/. Dry runs and pilots report the result without refusing.
    """
    from lipid_library import general_policy

    lib, data = cfg["library"], cfg["paths"]["general_data"]
    try:
        rep = general_policy.check(data, lib["n_3d"], lib["store_2d"], lib["general_policy_sample"],
                                   os.path.join(data, "dict.txt"))
    except ImportError as exc:                  # lmdb/numpy missing in this python
        rep = {"compatible": False, "problems": ["cannot run the check here: {}".format(exc)], "splits": {}}
    verdict = "COMPATIBLE" if rep["compatible"] else "NOT VERIFIED/INCOMPATIBLE"
    out("general ligand slot policy ({} vs lipid {}x3D, STORE_2D={}): {}".format(
        data, lib["n_3d"], lib["store_2d"], verdict))
    for split, r in rep.get("splits", {}).items():
        out("  {} {} sampled: profiles {} (dominant {})".format(split, r.get("n_checked"),
                                                               json.dumps(r.get("profiles")), r.get("dominant_profile")))
    for p in rep["problems"]:
        out("  PROBLEM: {}".format(p))
    if submit:
        os.makedirs(jobs_dir, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        with open(os.path.join(jobs_dir, "general_policy_check-{}.json".format(stamp)), "w", encoding="utf-8") as fh:
            json.dump(rep, fh, indent=2, sort_keys=True, default=str)
        if not rep["compatible"] and not pilot:
            raise Refused("stage 04 refused: the general ligand conformer policy could not be confirmed to "
                          "match the lipid policy (see above); nothing was submitted")
    return rep


def cmd_library(ns, cfg, cfg_path, cfg_sha, out=print):
    problems = _fixed_checks(cfg)
    if problems:
        raise Refused("; ".join(problems))
    lib = cfg["library"]
    root = cfg["paths"]["lipid_root"]
    lmdb_dir, limit, rps = None, None, None
    if ns.pilot:
        lmdb_dir = "{}/lmdb-limit{}".format(cfg["paths"]["lipid_pilot_root"].rstrip("/"), ns.pilot)
        limit, rps = ns.pilot, ns.pilot_records_per_shard
    status = ST.library_status(root, lmdb_dir, lib["chunk_size"], lib["enum_array_size"], lib["stage04_stride"],
                               lib["expected_combinations"])
    if ns.status:
        out(json.dumps(status, indent=2, default=str) if ns.json else ST.format_status(status))
        return 0
    if ns.verify_full:
        return _verify_full(ns, cfg, cfg_path, cfg_sha, root, lmdb_dir or status["lmdb"], limit, rps, out)
    plan = plan_library(status, ns.resume or bool(ns.pilot), ns.pilot, ns.from_stage)
    out(ST.format_status(status))
    if not plan:
        out("nothing to submit: the library is complete ({}).".format(lmdb_dir or status["lmdb"]))
        return 0
    if ns.submit:
        if not _have_sbatch():
            raise Refused("sbatch not found: submit from a CMRI login node")
        names = {C.profile(cfg, LIB_STAGE_PROFILE[s])["job_name"] for s, _ in plan}
        busy = _running_jobs(names)
        if busy and not ns.allow_concurrent:
            raise Refused("library jobs are already queued/running: {} (wait, or scancel them first)".format(busy))
        if plan[0][0] == "01" and not os.access(cfg["paths"]["lipid_input"], os.R_OK):
            raise Refused("building-block sheet not readable: {}".format(cfg["paths"]["lipid_input"]))
    if any(s == "04" for s, _ in plan):
        general_policy_gate(cfg, ns.submit, os.path.join(root, "jobs"), bool(ns.pilot), out)
    sub = Submitter(cfg, cfg_path, cfg_sha, ns.submit, os.path.join(root, "jobs"), out)
    snap = sub.snapshot()
    prev = None
    for stage, array in plan:
        prof = LIB_STAGE_PROFILE[stage]
        env = dict(common_env(cfg, snap, cfg_sha, prof), **library_env(cfg, root, lmdb_dir, limit, rps))
        dep = None
        if prev is not None:
            dep = ("afterany:" if stage == "05" else "afterok:") + prev
        prev = sub.run(stage, prof, env, dependency=dep, array=array, lipid_root=root)
    out("")
    out("stage 05 uses afterany: it runs after an incomplete stage 04 and fails closed (missing-shard report);")
    out("library completion never submits continual training (use `bin/heart continual ...`).")
    if not ns.submit:
        out("DRY RUN: nothing submitted. Add --submit to submit exactly these commands.")
    return 0


def _verify_full(ns, cfg, cfg_path, cfg_sha, root, lmdb_dir, limit, rps, out):
    """Submit (or preview) the lipid_verify job: full sha256 of every shard vs manifest.json."""
    from lipid_library import ready

    if not os.path.isfile(os.path.join(lmdb_dir, ready.READY)) and ns.submit:
        raise Refused("{} has no library_ready.json: finish stage 05 first".format(lmdb_dir))
    if ns.submit and not _have_sbatch():
        raise Refused("sbatch not found: submit from a CMRI login node")
    sub = Submitter(cfg, cfg_path, cfg_sha, ns.submit, os.path.join(root, "jobs"), out)
    snap = sub.snapshot()
    env = dict(common_env(cfg, snap, cfg_sha, "lipid_verify"), **library_env(cfg, root, lmdb_dir, limit, rps))
    sub.run("verify", "lipid_verify", env, lipid_root=root)
    if not ns.submit:
        out("DRY RUN: nothing submitted.")
    return 0


def cmd_bench(ns, cfg, out=print):
    """Stage-04 CPU-scaling benchmark: isolated pilot-size runs at several worker counts.

    Every run requests the PRODUCTION stage-04 allocation (250 CPUs, 500G, gpu:h200:1, cmri-gpu04)
    and only varies LIPID_WORKERS, so the runs differ in concurrency only. Runs are serialised
    (each 04 waits for the previous one) and read the production enumeration + dedup read-only.
    """
    b, lib = cfg["benchmark"], cfg["library"]
    workers = [int(w) for w in (ns.workers.split(",") if ns.workers else b["workers"])]
    n = int(ns.molecules or b["molecules"])
    if n > 100000:
        raise Refused("--molecules {} is not a benchmark (max 100000); production runs use bin/heart library".format(n))
    cpus = C.profile(cfg, "lipid_04")["cpus_per_task"]
    if any(w < 1 or w > cpus for w in workers):
        raise Refused("worker counts must be in 1..{} (the stage-04 allocation)".format(cpus))
    root = cfg["paths"]["lipid_root"]
    st = ST.library_status(root, None, lib["chunk_size"], lib["enum_array_size"], lib["stage04_stride"],
                           lib["expected_combinations"])
    if st["stages"]["03"]["state"] != "done" and ns.submit:
        raise Refused("the benchmark reads the production enumeration + dedup: stage 03 must be done first")
    bcfg = C.apply_overrides(cfg, ["slurm.profiles.lipid_04.time={}".format(b["time"]),
                                   "slurm.profiles.lipid_04.job_name=lipid-04-bench"])
    bsha = C.config_hash(bcfg)
    if ns.submit and not _have_sbatch():
        raise Refused("sbatch not found: submit from a CMRI login node")
    sub = Submitter(bcfg, None, bsha, ns.submit, os.path.join(root, "jobs"), out)
    snap = sub.snapshot()
    rps = int(b["records_per_shard"])
    dirs, prev04 = [], None
    for w in workers:
        d = "{}/bench-n{}-r{}-w{}".format(cfg["paths"]["lipid_pilot_root"].rstrip("/"), n, rps, w)
        dirs.append(d)
        env = dict(common_env(bcfg, snap, bsha, "lipid_03b"), **library_env(bcfg, root, d, n, rps))
        j3b = sub.run("03b-w{}".format(w), "lipid_03b", env, lipid_root=root)
        env = dict(common_env(bcfg, snap, bsha, "lipid_04"), **library_env(bcfg, root, d, n, rps))
        env["LIPID_WORKERS"] = str(w)
        dep = "afterok:{}".format(j3b) + (",afterany:{}".format(prev04) if prev04 else "")
        prev04 = sub.run("04-w{}".format(w), "lipid_04", env, dependency=dep, lipid_root=root)
    out("")
    out("{} molecules x {} records/shard = {} shards per run; each run reserves the full stage-04 profile.".format(
        n, rps, -(-n // rps)))
    out("after the runs: cd model/pretrain && python -m lipid_library.bench_report " + " ".join(dirs))
    if not ns.submit:
        out("DRY RUN: nothing submitted. Add --submit (needs approval: {} H200-node jobs).".format(len(workers)))
    return 0


# --------------------------------------------------------------------------- continual
def continual_env(cfg, cfg_path, cfg_sha, smoke, run_name, lmdb_dir):
    c, p = cfg["continual"], cfg["paths"]
    env = dict(common_env(cfg, cfg_path, cfg_sha, "continual"))
    env.update({"HEART_CONFIRM_CONTINUAL": "1", "HEART_GENERAL_CHECKPOINT": p["general_checkpoint"],
                "HEART_LIPID_SPLITS": "{}/splits.json".format(lmdb_dir.rstrip("/")),
                "HEART_OUTPUT_ROOT": p["continual_output_root"], "RUN_NAME": run_name,
                "BATCH_SIZE": str(c["batch_size"]), "UPDATE_FREQ": str(c["update_freq"]),
                "NUM_WORKERS": str(c["num_workers"]), "N_GPU": str(c["n_gpu"]), "MAX_STEPS": str(c["max_steps"]),
                "GENERAL_DATA_WEIGHT": str(c["general_data_weight"]), "LIPID_DATA_WEIGHT": str(c["lipid_data_weight"]),
                "MAX_OPEN_LMDB_ENVS": str(c["max_open_lmdb_envs"]), "HEART_REQUIRE_LIBRARY_READY": "1"})
    if smoke:
        env["HEART_CONTINUAL_SMOKE_UPDATES"] = str(c["smoke_updates"])
    return env


def cmd_continual(ns, cfg, cfg_path, cfg_sha, out=print):
    from lipid_library import ready

    problems = _fixed_checks(cfg)
    if problems:
        raise Refused("; ".join(problems))
    c, p = cfg["continual"], cfg["paths"]
    run_name = ns.run_name or (c["smoke_run_name"] if ns.smoke else c["run_name"])
    if ns.smoke and "smoke" not in run_name:
        raise Refused("a smoke run needs a run name containing 'smoke'")
    if not ns.smoke and "smoke" in run_name:
        raise Refused("run names containing 'smoke' are reserved for --smoke")
    lmdb_dir = ns.lipid_lmdb_dir or "{}/lmdb".format(p["lipid_root"].rstrip("/"))
    # v2 hardening: quick integrity of EVERY shard (size + sampled digest + mtime) on every call, and
    # for a submission a FULL sha256 verification younger than continual.full_verify_max_age_days.
    max_age = c["full_verify_max_age_days"] if ns.submit else None
    record, rproblems = ready.verify(lmdb_dir, allow_smoke=False, max_age_days=max_age) if os.path.isdir(
        lmdb_dir) else (None, ["{} does not exist here".format(lmdb_dir)])
    run_dir = "{}/continual/{}".format(p["continual_output_root"].rstrip("/"), run_name)
    pc = C.profile(cfg, "continual")
    out("continual profile: {} | gres {} | {} CPUs | {} | time {} | batch {} x update-freq {} | {} updates".format(
        pc["partition"], pc["gres"], pc["cpus_per_task"], pc["mem"], pc["time"], c["batch_size"],
        c["update_freq"], c["smoke_updates"] if ns.smoke else c["max_steps"]))
    out("general checkpoint (read-only): {}".format(p["general_checkpoint"]))
    out("lipid library: {} -> {}".format(lmdb_dir, "READY" if record else "NOT READY: " + "; ".join(rproblems)))
    resume = os.path.isfile(os.path.join(run_dir, "checkpoint_last.pt"))
    out("run dir: {} ({})".format(run_dir, "RESUME from its checkpoint_last.pt" if resume else
                                  "NEW stage: init from the general checkpoint, optimizer/schedule reset"))
    env = continual_env(cfg, cfg_path, cfg_sha, ns.smoke, run_name, lmdb_dir)
    if ns.check:
        cmd = ["bash", S.script_path(cfg, "continual")]
        envp = dict(os.environ, **env, HEART_DRY_RUN="1", PYTHONDONTWRITEBYTECODE="1")
        envp.pop("HEART_V2_PROFILE", None)
        envp.pop("SLURM_JOB_ID", None)          # a check is never a job (no stop-time, no guard path)
        out("read-only preflight (HEART_DRY_RUN=1, writes nothing): {}".format(" ".join(cmd)))
        if record is None and not ns.ignore_ready:
            raise Refused("lipid library not ready: " + "; ".join(rproblems))
        if ns.print_only:
            return 0
        return subprocess.run(cmd, env=envp).returncode
    if ns.submit:
        if record is None:
            raise Refused("refusing to submit: lipid library not ready ({})".format("; ".join(rproblems)))
        if not os.access(p["general_checkpoint"], os.R_OK):
            raise Refused("general checkpoint not readable: {}".format(p["general_checkpoint"]))
        if not _have_sbatch():
            raise Refused("sbatch not found: submit from a CMRI login node")
        busy = _running_jobs({pc["job_name"]})
        if busy and not ns.allow_concurrent:
            raise Refused("a continual job is already queued/running: {}".format(busy))
    sub = Submitter(cfg, cfg_path, cfg_sha, ns.submit, os.path.join(p["continual_output_root"], "jobs"), out)
    env["HEART_V2_CONFIG"] = sub.snapshot()
    sub.run("continual-smoke" if ns.smoke else "continual", "continual", env)
    if not ns.submit:
        out("DRY RUN: nothing submitted. Add --submit (after `bin/heart continual --check`).")
    return 0


# --------------------------------------------------------------------------- evaluate / check / baseline
def cmd_evaluate(ns, cfg, out=print):
    p, c = cfg["paths"], cfg["continual"]
    run_dir = ns.run_dir or "{}/continual/{}".format(p["continual_output_root"].rstrip("/"), c["run_name"])
    out("general checkpoint : {} ({})".format(p["general_checkpoint"],
                                               "found" if os.path.isfile(p["general_checkpoint"]) else "NOT FOUND here"))
    out("continual run dir  : {}".format(run_dir))
    found = {}
    for f in ("checkpoint_best.pt", "checkpoint_last.pt", "continual_stage.json", "mixture_report.json",
              "continual_init_report.json"):
        found[f] = os.path.isfile(os.path.join(run_dir, f))
        out("  {:<28} {}".format(f, "present" if found[f] else "missing"))
    notebooks = [os.path.join("model", n) for n in ("HEART_H200_checkpoint_best_embedding_evaluation.ipynb",
                                                    "HEART_best_checkpoint_embedding_evaluation.ipynb")]
    out("historical general evaluation notebooks (unchanged, read-only): {}".format(", ".join(notebooks)))
    tool = os.path.join(C.PRETRAIN_DIR, "tools", "v2_compare_checkpoints.py")
    cont = os.path.join(run_dir, "checkpoint_best.pt")
    cmd = [sys.executable, tool, p["general_checkpoint"], cont, "--json-out",
           os.path.join(run_dir, "v2_checkpoint_comparison.json")]
    out("read-only comparison: {}".format(S.shell_join(cmd)))
    if found["checkpoint_best.pt"] and os.path.isfile(p["general_checkpoint"]) and not ns.print_only:
        return subprocess.run(cmd).returncode
    out("(skipped: needs both checkpoints; evaluation status PENDING_HPC)")
    return 0


def cmd_check(cfg, cfg_path, warnings, out=print):
    ok = True
    out("config: {} (sha256 {})".format(cfg_path, C.config_hash(cfg)[:16]))
    for w in warnings:
        out("  WARNING: {}".format(w))
    for p in _fixed_checks(cfg):
        out("  FAIL: {}".format(p))
        ok = False
    for name in sorted(cfg["slurm"]["profiles"]):
        mism = S.header_mismatches(cfg, name)
        out("  #SBATCH header {:<15} {}".format(name, "matches config" if not mism else "MISMATCH: " + "; ".join(mism)))
        ok = ok and not mism
    for name in ("lipid_04", "continual"):
        pr = C.profile(cfg, name)
        out("  H200 profile {:<10} gres {} | {} CPUs | {} | node {} | time {}".format(
            name, pr["gres"], pr["cpus_per_task"], pr["mem"], pr.get("nodelist") or "(scheduler)", pr["time"]))
    b = baseline.verify()
    out("  general baseline: {} ({} protected upstream files, {} approved path migrations; upstream {}{})".format(
        "PASS" if b["pass"] else "FAIL", b["n_protected"], len(b.get("path_migrated", [])), b["upstream_sha"][:7],
        "; modified: {}; missing: {}".format(b["modified"], b["missing"]) if not b["pass"] else ""))
    ok = ok and b["pass"]
    for key in ("general_data", "general_checkpoint", "lipid_root", "lipid_input", "unicore_src"):
        path = cfg["paths"][key]
        out("  path {:<20} {:<9} {}".format(key, "found" if os.path.exists(path) else "not here", path))
    out("check: {}".format("PASS" if ok else "FAIL"))
    return 0 if ok else 1


# --------------------------------------------------------------------------- argument parsing
def build_parser():
    ap = argparse.ArgumentParser(prog="heart", description=__doc__.splitlines()[0])
    ap.add_argument("--config", default=None)
    ap.add_argument("--set", dest="overrides", action="append", default=[])
    ap.add_argument("--json", action="store_true")
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("check")
    r = sp.add_parser("render")
    r.add_argument("profile")
    b = sp.add_parser("baseline")
    b.add_argument("--generate", action="store_true", help=argparse.SUPPRESS)
    lib = sp.add_parser("library")
    g = lib.add_mutually_exclusive_group()
    g.add_argument("--status", action="store_true")
    g.add_argument("--dry-run", action="store_true")
    g.add_argument("--submit", action="store_true")
    lib.add_argument("--resume", action="store_true")
    lib.add_argument("--pilot", type=int, default=None, metavar="N")
    lib.add_argument("--pilot-records-per-shard", type=int, default=10)
    lib.add_argument("--from-stage", default=None, help="advanced: (re)submit from this stage on")
    lib.add_argument("--allow-concurrent", action="store_true")
    lib.add_argument("--verify-full", action="store_true",
                     help="(re)verify the sha256 of every shard of a finished library as a CPU job")
    co = sp.add_parser("continual")
    g = co.add_mutually_exclusive_group()
    g.add_argument("--check", action="store_true")
    g.add_argument("--dry-run", action="store_true")
    g.add_argument("--submit", action="store_true")
    co.add_argument("--smoke", action="store_true")
    co.add_argument("--run-name", default=None)
    co.add_argument("--lipid-lmdb-dir", default=None)
    co.add_argument("--allow-concurrent", action="store_true")
    co.add_argument("--ignore-ready", action="store_true", help=argparse.SUPPRESS)
    co.add_argument("--print-only", action="store_true", help=argparse.SUPPRESS)
    be = sp.add_parser("bench")
    g = be.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true")
    g.add_argument("--submit", action="store_true")
    be.add_argument("--workers", default=None, help="comma list (default config benchmark.workers)")
    be.add_argument("--molecules", type=int, default=None)
    ev = sp.add_parser("evaluate")
    ev.add_argument("--check", action="store_true", required=True)
    ev.add_argument("--run-dir", default=None)
    ev.add_argument("--print-only", action="store_true")
    return ap


def main(argv=None, out=print):
    ns = build_parser().parse_args(argv)
    try:
        if ns.cmd == "baseline" and ns.generate:
            m = baseline.generate()
            out("wrote {} ({} protected files)".format(baseline.MANIFEST, m["n_protected"]))
            return 0
        if ns.cmd == "baseline":
            r = baseline.verify()
            out(json.dumps(r, indent=2) if ns.json else
                "general baseline: {} ({} upstream protected; {} byte-identical; {} approved path migrations; {})".format(
                    "PASS" if r["pass"] else "FAIL", r["n_protected"], r.get("n_upstream_byte_identical", "?"),
                    len(r.get("path_migrated", [])), r["upstream_sha"]))
            for k in ("modified", "missing", "path_migrated"):
                for f in r.get(k, []):
                    out("  {}: {}".format(k.upper(), f))
            return 0 if r["pass"] else 1
        cfg, cfg_path, warnings = C.load(ns.config, ns.overrides)
        cfg_sha = C.config_hash(cfg)
        if ns.cmd == "check":
            return cmd_check(cfg, cfg_path, warnings, out)
        for w in warnings:
            out("WARNING: {}".format(w))
        if ns.cmd == "render":
            out(S.shell_join(S.render(cfg, ns.profile)))
            return 0
        if ns.cmd == "library":
            return cmd_library(ns, cfg, cfg_path, cfg_sha, out)
        if ns.cmd == "continual":
            return cmd_continual(ns, cfg, cfg_path, cfg_sha, out)
        if ns.cmd == "bench":
            return cmd_bench(ns, cfg, out)
        if ns.cmd == "evaluate":
            return cmd_evaluate(ns, cfg, out)
    except (C.ConfigError, Refused) as exc:
        out("REFUSED: {}".format(exc))
        return 2
    return 1


if __name__ == "__main__":
    sys.exit(main())
