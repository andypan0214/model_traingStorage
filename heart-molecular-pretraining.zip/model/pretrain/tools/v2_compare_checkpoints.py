#!/usr/bin/env python
"""Read-only post-continual diagnostic: general checkpoint vs continual checkpoint.

    python pretrain/tools/v2_compare_checkpoints.py GENERAL.pt CONTINUAL.pt [--json-out f]

Reports (nothing is modified; both files are only torch.load-ed on the CPU):
  * task / arch / update counters of both checkpoints (general:
    unimol_contrastive at 1,000,000 updates; continual: unimol_contrastive_continual);
  * strict parameter agreement: identical parameter names and shapes, so the
    continual model is the same architecture and dictionary size;
  * per-module relative weight drift ||W_c - W_g|| / ||W_g|| (embedding, each
    encoder layer, heads), the overall drift and the largest movers. A drift of
    exactly 0 means the continual run never updated the weights; a very large
    drift in the backbone would be a warning sign of forgetting.
This is a representation diagnostic, NOT downstream lipid-delivery accuracy.
For embedding plots, run the unchanged historical notebook
model/HEART_H200_checkpoint_best_embedding_evaluation.ipynb with the continual
checkpoint path (it is not edited by v2).
Exit 0 = comparable (names/shapes identical); 1 = incompatible.
"""
import argparse
import json
import math
import re
import sys


def _load(path):
    import torch

    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:          # torch < 1.13
        return torch.load(path, map_location="cpu")


def _meta(ck):
    args = ck.get("args")
    if args is None and isinstance(ck.get("cfg"), dict):
        args = ck["cfg"].get("model")
    hist = ck.get("optimizer_history") or [{}]
    get = (lambda k: getattr(args, k, None)) if args is not None and not isinstance(args, dict) else \
        (lambda k: (args or {}).get(k))
    return {"task": get("task"), "arch": get("arch"), "num_updates": hist[-1].get("num_updates"),
            "lr": get("lr"), "max_update": get("max_update")}


def _group(name):
    m = re.search(r"layers\.(\d+)\.", name)
    if m:
        return "encoder.layer{:02d}".format(int(m.group(1)))
    for key in ("embed_tokens", "gbf", "pair", "lm_head", "pair2coord", "dist_head", "contrastive", "proj"):
        if key in name:
            return key
    return name.split(".")[0]


def compare(general, continual):
    import torch

    g, c = general["model"], continual["model"]
    out = {"general": _meta(general), "continual": _meta(continual)}
    only_g, only_c = sorted(set(g) - set(c)), sorted(set(c) - set(g))
    shape = sorted(k for k in set(g) & set(c) if tuple(g[k].shape) != tuple(c[k].shape))
    out.update({"missing_in_continual": only_g, "unexpected_in_continual": only_c, "shape_mismatch": shape,
                "compatible": not (only_g or only_c or shape)})
    groups, num, den = {}, 0.0, 0.0
    movers = []
    for k in sorted(set(g) & set(c)):
        if k in shape or not torch.is_floating_point(g[k]):
            continue
        a, b = g[k].double(), c[k].double()
        d2, n2 = float(((b - a) ** 2).sum()), float((a ** 2).sum())
        num, den = num + d2, den + n2
        grp = groups.setdefault(_group(k), [0.0, 0.0])
        grp[0] += d2
        grp[1] += n2
        movers.append((math.sqrt(d2 / n2) if n2 > 0 else float("inf") if d2 > 0 else 0.0, k))
    out["relative_drift_overall"] = math.sqrt(num / den) if den else None
    out["relative_drift_by_group"] = {k: (math.sqrt(v[0] / v[1]) if v[1] else None) for k, v in sorted(groups.items())}
    out["largest_relative_drift"] = [{"param": k, "drift": r} for r, k in sorted(movers, reverse=True)[:10]]
    out["identical_weights"] = num == 0.0
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("general")
    ap.add_argument("continual")
    ap.add_argument("--json-out", default=None)
    ns = ap.parse_args(argv)
    r = compare(_load(ns.general), _load(ns.continual))
    print("general  : task {task} arch {arch} updates {num_updates}".format(**r["general"]))
    print("continual: task {task} arch {arch} updates {num_updates}".format(**r["continual"]))
    print("names/shapes identical: {}".format(r["compatible"]))
    for k in ("missing_in_continual", "unexpected_in_continual", "shape_mismatch"):
        if r[k]:
            print("  {}: {}".format(k, r[k][:10]))
    if r["relative_drift_overall"] is not None:
        print("relative weight drift overall: {:.4g}".format(r["relative_drift_overall"]))
        for k, v in r["relative_drift_by_group"].items():
            print("  {:<18} {}".format(k, "n/a" if v is None else "{:.4g}".format(v)))
    if r["identical_weights"]:
        print("WARNING: the continual weights are identical to the general ones (no update was applied)")
    if ns.json_out:
        with open(ns.json_out, "w", encoding="utf-8") as fh:
            json.dump(r, fh, indent=2, default=str)
        print("wrote {}".format(ns.json_out))
    return 0 if r["compatible"] else 1


if __name__ == "__main__":
    sys.exit(main())
