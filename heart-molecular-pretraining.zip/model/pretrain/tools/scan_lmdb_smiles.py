#!/usr/bin/env python
"""Read-only scan of a Uni-Mol ligand LMDB for records the HEART pipeline cannot use as-is.

Streams the records one at a time (nothing is materialised in RAM), applies
exactly the checks of the training code (unimol/data/add_2d_conformer_dataset.py,
patch P6) and writes every problem record to a TSV. The LMDB is opened with
readonly=True, lock=False and never modified.

Categories
  2D skipped (training keeps the record with its stored 3D conformers only):
    smiles_not_string, smiles_empty, smiles_syntax, smiles_sanitize,
    2d_atom_mismatch (AddHs gives other atoms than the record), 2d_coords_invalid
  fatal (training would stop on this record, or its 3D data are unusable):
    unpicklable, not_a_dict, missing_field, no_atoms, no_3d_conformer,
    3d_shape_mismatch, 3d_nonfinite

Modes
  default            sequential cursor scan of the whole LMDB (fastest on disk)
  --limit N          stop after N records
  --start A --end B  only indices A <= i < B (random reads; for parallel shards)
  --sample N         N random indices (seeded), a quick pre-flight check
  --fast             parse + AddHs atom check only, no Compute2DCoords

Usage (from .../heart-molecular-pretraining/model, heart_gpu activated):
    python pretrain/tools/scan_lmdb_smiles.py \\
        /project/yli4/ypan/UniMolReference/ligand_data/ligands/train.lmdb \\
        --out-dir ../runs/lmdb_scan/train
Exit code 0 when no fatal record was found and the 2D-skipped fraction is at
most --max-skip-fraction (training's --max-invalid-smiles-fraction); else 1.
"""
import argparse
import importlib.util
import json
import os
import pickle
import random
import sys
import time
from collections import Counter

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ADD2D_PATH = os.path.join(HERE, "..", "..", "unimol", "data", "add_2d_conformer_dataset.py")
FATAL = {"unpicklable", "not_a_dict", "missing_field", "no_atoms", "no_3d_conformer",
         "3d_shape_mismatch", "3d_nonfinite"}


def load_add2d():
    """The training module itself (not a copy), loaded without the unimol package __init__."""
    spec = importlib.util.spec_from_file_location("heart_add_2d_conformer", os.path.abspath(ADD2D_PATH))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def open_ro(path):
    import lmdb

    return lmdb.open(path, subdir=False, readonly=True, lock=False, readahead=False,
                     meminit=False, max_readers=256)


def categorise_2d(add2d, smi, atoms, fast):
    """None if the 2D conformer would be added in training, else (category, reason)."""
    mol, reason = add2d.parse_smiles(smi)
    if mol is None:
        if not isinstance(smi, str):
            return "smiles_not_string", reason
        if reason == "SMILES is empty":
            return "smiles_empty", reason
        if reason.startswith("SMILES syntax"):
            return "smiles_syntax", reason
        return "smiles_sanitize", reason
    if fast:
        from rdkit import Chem

        symbols = [a.GetSymbol() for a in Chem.AddHs(mol).GetAtoms()]
        if symbols != [str(a) for a in atoms]:
            return "2d_atom_mismatch", "AddHs gives {} atoms, record has {} (or order differs)".format(
                len(symbols), len(atoms))
        return None
    try:
        add2d.smi2_2Dcoords(smi, atoms)
    except add2d.Invalid2DConformer as exc:
        msg = str(exc)
        return ("2d_coords_invalid" if msg.startswith("RDKit 2D coordinates") else "2d_atom_mismatch"), msg
    return None


def check_record(add2d, raw, fast):
    """List of (category, reason) problems of one pickled record."""
    try:
        rec = pickle.loads(raw)
    except Exception as exc:  # reported per record, never hidden
        return [("unpicklable", repr(exc))], None
    if not isinstance(rec, dict):
        return [("not_a_dict", type(rec).__name__)], None
    missing = [k for k in ("atoms", "coordinates", "smi") if k not in rec]
    if missing:
        return [("missing_field", ",".join(missing))], rec.get("smi")
    smi, atoms, coords = rec["smi"], list(rec["atoms"]), rec["coordinates"]
    problems = []
    if len(atoms) == 0:
        return [("no_atoms", "empty atom list")], smi
    if not isinstance(coords, (list, tuple)) or len(coords) == 0:
        problems.append(("no_3d_conformer", "coordinates is {} of length {}".format(
            type(coords).__name__, len(coords) if hasattr(coords, "__len__") else "?")))
    else:
        for k, c in enumerate(coords):
            arr = np.asarray(c)
            if arr.shape != (len(atoms), 3):
                problems.append(("3d_shape_mismatch", "conformer {} has shape {}, record has {} atoms".format(
                    k, arr.shape, len(atoms))))
                break
            if not np.isfinite(arr).all():
                problems.append(("3d_nonfinite", "conformer {} has NaN/Inf".format(k)))
                break
    p2d = categorise_2d(add2d, smi, atoms, fast)
    if p2d is not None:
        problems.append(p2d)
    return problems, smi


def iter_records(env, ns, n_entries):
    """Yield (index, raw bytes or None)."""
    with env.begin(buffers=False) as txn:
        if ns.sample:
            rng = random.Random(ns.seed)
            for i in sorted(rng.sample(range(n_entries), min(ns.sample, n_entries))):
                yield i, txn.get(str(i).encode("ascii"))
        elif ns.start is not None or ns.end is not None:
            start, end = ns.start or 0, min(ns.end if ns.end is not None else n_entries, n_entries)
            for i in range(start, end):
                if ns.limit and i - start >= ns.limit:
                    return
                yield i, txn.get(str(i).encode("ascii"))
        else:
            for n, (key, raw) in enumerate(txn.cursor()):
                if ns.limit and n >= ns.limit:
                    return
                yield int(key.decode("ascii")), raw


def tsv_field(v):
    return str(v).replace("\t", " ").replace("\n", " ")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("lmdb_path")
    ap.add_argument("--out-dir", required=True, help="problems.tsv + summary.json (outside the data directory)")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--start", type=int)
    ap.add_argument("--end", type=int)
    ap.add_argument("--sample", type=int, default=0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--fast", action="store_true")
    ap.add_argument("--progress", type=int, default=500000, help="print progress every N records")
    ap.add_argument("--max-skip-fraction", type=float, default=0.01)
    ns = ap.parse_args(argv)

    lmdb_path = os.path.abspath(ns.lmdb_path)
    data_dir = os.path.dirname(lmdb_path)
    out_dir = os.path.abspath(ns.out_dir)
    if (out_dir + os.sep).startswith(data_dir + os.sep):
        print("refusing to write inside the data directory {}".format(data_dir), file=sys.stderr)
        return 2
    if not os.path.isfile(lmdb_path):
        print("not found: {}".format(lmdb_path), file=sys.stderr)
        return 2
    os.makedirs(out_dir, exist_ok=True)

    add2d = load_add2d()
    import rdkit

    env = open_ro(lmdb_path)
    t0 = time.time()
    counts, n, n_records_with_problems = Counter(), 0, 0
    n_fatal = n_skip = n_missing_key = 0
    tsv_path = os.path.join(out_dir, "problems.tsv")
    try:
        with env.begin() as txn:
            n_entries = txn.stat()["entries"]
        with open(tsv_path, "w", encoding="utf-8", newline="\n") as tsv:
            tsv.write("index\tcategory\tseverity\treason\tsmi\n")
            for idx, raw in iter_records(env, ns, n_entries):
                n += 1
                if raw is None:
                    problems, smi = [("missing_key", "key b'{}' absent".format(idx))], None
                    n_missing_key += 1
                else:
                    problems, smi = check_record(add2d, raw, ns.fast)
                if problems:
                    n_records_with_problems += 1
                    fatal = any(c in FATAL or c == "missing_key" for c, _ in problems)
                    n_fatal += fatal
                    n_skip += (not fatal)
                    for cat, reason in problems:
                        counts[cat] += 1
                        sev = "fatal" if cat in FATAL or cat == "missing_key" else "2d_skipped"
                        tsv.write("{}\t{}\t{}\t{}\t{}\n".format(idx, cat, sev, tsv_field(reason), tsv_field(smi)))
                if ns.progress and n % ns.progress == 0:
                    rate = n / max(time.time() - t0, 1e-9)
                    print("[scan] {:,} records | {:,} 2D-skipped | {:,} fatal | {:.0f} rec/s".format(
                        n, n_skip, n_fatal, rate), flush=True)
    finally:
        env.close()

    elapsed = time.time() - t0
    skip_fraction = n_skip / n if n else 0.0
    summary = {
        "lmdb": lmdb_path, "entries": n_entries, "scanned": n,
        "mode": "sample" if ns.sample else ("range" if ns.start is not None or ns.end is not None else "cursor"),
        "fast": ns.fast, "rdkit": rdkit.__version__, "elapsed_s": round(elapsed, 1),
        "records_with_problems": n_records_with_problems, "records_2d_skipped": n_skip,
        "records_fatal": n_fatal, "missing_keys": n_missing_key,
        "skip_fraction": skip_fraction, "max_skip_fraction": ns.max_skip_fraction,
        "categories": dict(sorted(counts.items())), "problems_tsv": tsv_path,
    }
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)
    print(json.dumps(summary, indent=2))
    ok_fatal = n_fatal == 0
    ok_frac = skip_fraction <= ns.max_skip_fraction
    print("{}  no fatal records ({} found)".format("PASS" if ok_fatal else "FAIL", n_fatal))
    print("{}  2D-skipped fraction {:.6f} <= {:g} ({} records keep only their 3D conformers)".format(
        "PASS" if ok_frac else "FAIL", skip_fraction, ns.max_skip_fraction, n_skip))
    return 0 if ok_fatal and ok_frac else 1


if __name__ == "__main__":
    sys.exit(main())
