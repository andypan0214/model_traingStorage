"""Advisory lock on a stage-04 output directory (mutually exclusive writers).

* The single-allocation pool (`stage04_pool`) takes it EXCLUSIVELY for its
  whole run: a second pool, or any array task, on the same LMDB directory
  fails immediately instead of writing the same shard twice.
* Array tasks (`lmdb_writer --shard`) take it SHARED: many array tasks may run
  together, but never alongside a pool.

POSIX `fcntl.lockf`/`flock` locks are released by the kernel when the process
dies (SLURM time limit, OOM kill, node loss), so there is no stale lock to
clean up. On Linux NFS (v4) `flock` is emulated with byte-range locks and is
honoured across nodes. Windows (local tests only) uses msvcrt, exclusive only.
"""
import json
import os
import socket
import time

LOCK_NAME = ".stage04.lock"
OWNER_NAME = "stage04_owner.json"


class LockBusy(RuntimeError):
    """Another writer holds the stage-04 lock of this directory."""


class DirLock:
    def __init__(self, out_dir, shared=False, label="stage04"):
        self.out_dir = out_dir
        self.shared = shared
        self.label = label
        self.path = os.path.join(out_dir, LOCK_NAME)
        self._fh = None

    def acquire(self):
        os.makedirs(self.out_dir, exist_ok=True)
        fh = open(self.path, "a+")
        try:
            try:
                import fcntl

                mode = fcntl.LOCK_SH if self.shared else fcntl.LOCK_EX
                fcntl.flock(fh.fileno(), mode | fcntl.LOCK_NB)
            except ImportError:            # Windows: tests only (no shared locks there)
                import msvcrt

                if not self.shared:
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            fh.close()
            raise LockBusy("{} is locked by another stage-04 writer ({}); see {}".format(
                self.out_dir, "a pool run" if self.shared else "a pool run or array tasks",
                os.path.join(self.out_dir, OWNER_NAME)))
        self._fh = fh
        if not self.shared:
            info = {"label": self.label, "host": socket.gethostname(), "pid": os.getpid(),
                    "slurm_job_id": os.environ.get("SLURM_JOB_ID"), "since": time.strftime("%Y-%m-%d %H:%M:%S")}
            tmp = os.path.join(self.out_dir, OWNER_NAME + ".tmp")
            with open(tmp, "w", encoding="utf-8") as out:
                json.dump(info, out, indent=2)
            os.replace(tmp, os.path.join(self.out_dir, OWNER_NAME))
        return self

    def release(self):
        if self._fh is not None:
            try:
                try:
                    import fcntl

                    fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
                except ImportError:
                    import msvcrt

                    if not self.shared:
                        self._fh.seek(0)
                        msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
            self._fh.close()
            self._fh = None

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *exc):
        self.release()
        return False
