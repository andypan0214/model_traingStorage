#!/usr/bin/env python
"""Stage-05 production-quality report and criteria (v2 hardening).

    python -m lipid_library.quality LMDB_DIR --enum-dir ENUM --dedup-dir DEDUP [--workers 16]
        -> LMDB_DIR/quality_report.json + quality_report.md ; exit 1 if a production criterion fails

Reports EVERYTHING that was lost or degraded between the 15,241,216 Ugi-4CR combinations and the
accepted records, and how much of the LMDB content stage-05 validation actually looked at:

  enumeration   combinations, products, Ugi failures (by reason), failure fraction
  dedup         duplicate product rows dropped (kept: lowest combination index)
  stage 04      input rows, accepted records, skipped molecules by reason and by category
                (conformer failure / no 3D embedding / atom limit / atom outside dict.txt / other),
                ETKDG+MMFF attempt counters, 2D fill-ins (records and slots), histograms of
                successful 3D embeddings and of DISTINCT 3D conformers per record
  validation    sampled vs full mode, records checked / stored, per-shard minimum depth,
                fallback-audit coverage and mismatches, problems

Criteria (config/heart_v2.yaml `library.quality`, docs/LIBRARY_QUALITY_CRITERIA.md) are ENFORCED for a
production library: any failure -> `passed: false` -> lipid_library.ready refuses library_ready.json.
For a smoke/pilot library they are evaluated and reported but not enforced.

10 stored coordinate slots are NOT 10 distinct successful 3D conformers: a slot can be a 2D fill-in
(embedding failed) and, with seed_start=0 (LUMI-faithful), ETKDG seeds 0 and 1 are identical in RDKit,
so the first two 3D slots normally coincide. Both are counted here.
"""
import argparse
import json
import os
import sys

from . import io_utils

DEFAULT_CRITERIA = {
    "max_skipped_fraction": 0.02,
    "max_unsupported_atom_records": 0,
    "max_records_with_2d_fill_fraction": 0.05,
    "max_2d_fill_slot_fraction": 0.01,
    "max_validation_problems": 0,
    "min_validation_records_per_shard": 500,
    "require_full_fallback_audit": True,
    "max_enumeration_failure_fraction": 0.05,
}
REPORT = "quality_report.json"


def load_criteria(path=None):
    """Criteria: --criteria-json file > config/heart_v2.yaml (HEART_V2_CONFIG snapshot) > defaults."""
    crit = dict(DEFAULT_CRITERIA)
    if path:
        with open(path, encoding="utf-8") as fh:
            crit.update(json.load(fh))
        return crit, path
    try:
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from heart_v2 import config as C

        cfg, cpath, _ = C.load()
        crit.update(cfg["library"].get("quality") or {})
        return crit, cpath
    except Exception as exc:                                     # noqa: BLE001
        return crit, "built-in defaults ({}: {})".format(type(exc).__name__, exc)


def _merge(dst, src):
    for k, v in (src or {}).items():
        dst[k] = dst.get(k, 0) + v


def skip_category(reason):
    r = reason.lower()
    if "not in dict.txt" in r:
        return "atom_outside_dict"
    if "exceeds --max-atoms" in r:
        return "atom_limit"
    if "no 3d conformer" in r:
        return "no_3d_embedding"
    if "conformer generation failed" in r or "cannot parse" in r:
        return "conformer_failure"
    return "other_exception"


def _hist_from_records(path, column):
    h = {}
    for row in io_utils.read_gz_csv(path):
        h[row[column]] = h.get(row[column], 0) + 1
    return h


def _shard_stats(args):
    lmdb_dir, s = args
    r = _load(os.path.join(lmdb_dir, s["dir"], "shard.json"))
    rec_csv = os.path.join(lmdb_dir, s["dir"], "records.csv.gz")
    for hk, col in (("n_3d_success_hist", "n_3d_success"), ("n_distinct_3d_hist", "n_distinct_3d")):
        if not r.get(hk):                       # receipts written before v2 hardening
            r[hk] = _hist_from_records(rec_csv, col)
    return {k: r.get(k) for k in ("n_input_rows", "n_records", "n_skipped", "skip_reasons", "unsupported_atoms",
                                  "n_records_with_2d_fill", "n_2d_filled_total", "n_3d_slots_total",
                                  "n_distinct_3d_total", "n_oversized", "conformer_attempts",
                                  "n_3d_success_hist", "n_distinct_3d_hist", "n_3d_slots_per_record")}


def _load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def build_report(lmdb_dir, enum_dir, dedup_dir, criteria, workers=1):
    manifest = _load(os.path.join(lmdb_dir, "manifest.json"))
    validation = _load(os.path.join(lmdb_dir, "validation.json"))
    rep = {"manifest_sha256": io_utils.sha256_file(os.path.join(lmdb_dir, "manifest.json")),
           "smoke": bool(manifest.get("smoke")), "criteria": criteria}

    # enumeration + dedup
    complete = _load(os.path.join(enum_dir, "enumeration_complete.json"))
    reasons = {}
    for c in complete.get("chunks", []):
        rp = os.path.join(enum_dir, c["products_file"].replace(".csv.gz", ".done.json"))
        if os.path.isfile(rp):
            _merge(reasons, _load(rp).get("failure_reasons"))
    n_comb = complete.get("n_combinations") or 0
    rep["enumeration"] = {"n_combinations": n_comb, "n_products": complete.get("n_products"),
                          "n_failures": complete.get("n_failures"),
                          "failure_fraction": (complete.get("n_failures") or 0) / float(n_comb) if n_comb else None,
                          "failure_reasons": dict(sorted(reasons.items(), key=lambda kv: -kv[1]))}
    dsum = _load(os.path.join(dedup_dir, "summary.json")) if os.path.isfile(os.path.join(dedup_dir, "summary.json")) else {}
    rep["dedup"] = {"n_unique_products": dsum.get("n_unique_products"),
                    "n_duplicate_rows_dropped": dsum.get("n_duplicate_rows")}

    # stage 04 accounting from every shard receipt
    jobs = [(lmdb_dir, s) for s in manifest["shards"]]
    if workers > 1 and len(jobs) > 1:
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=workers) as pool:
            per = list(pool.map(_shard_stats, jobs))
    else:
        per = [_shard_stats(j) for j in jobs]
    tot = {"n_input_rows": 0, "n_records": 0, "n_skipped": 0, "n_records_with_2d_fill": 0,
           "n_2d_filled_total": 0, "n_3d_slots_total": 0, "n_distinct_3d_total": 0, "n_oversized": 0}
    skip_reasons, unsupported, attempts, h3d, hdist = {}, {}, {}, {}, {}
    attempts_missing = 0
    for p in per:
        for k in tot:
            tot[k] += p.get(k) or 0
        _merge(skip_reasons, p["skip_reasons"])
        _merge(unsupported, p["unsupported_atoms"])
        if p.get("conformer_attempts") is None:
            attempts_missing += 1
        _merge(attempts, p.get("conformer_attempts"))
        _merge(h3d, p["n_3d_success_hist"])
        _merge(hdist, p["n_distinct_3d_hist"])
    n_slots_3d = int(manifest["shards"][0]["n_3d_slots_per_record"]) if manifest["shards"] else 10
    by_cat = {}
    for reason, n in skip_reasons.items():
        by_cat[skip_category(reason)] = by_cat.get(skip_category(reason), 0) + n
    n_rec, n_in = tot["n_records"], tot["n_input_rows"]
    n_unsupported_records = sum(n for r, n in skip_reasons.items() if skip_category(r) == "atom_outside_dict")
    rep["stage04"] = dict(
        tot, n_shards=len(per), skipped_fraction=tot["n_skipped"] / float(n_in) if n_in else None,
        skip_by_category=dict(sorted(by_cat.items())), skip_reasons=dict(sorted(skip_reasons.items(), key=lambda kv: -kv[1])),
        unsupported_atoms=unsupported, n_unsupported_atom_records=n_unsupported_records,
        records_with_2d_fill_fraction=tot["n_records_with_2d_fill"] / float(n_rec) if n_rec else None,
        slots_3d_per_record=n_slots_3d,
        fill_2d_slot_fraction=tot["n_2d_filled_total"] / float(n_rec * n_slots_3d) if n_rec else None,
        n_3d_success_hist=dict(sorted(h3d.items(), key=lambda kv: int(kv[0]))),
        n_distinct_3d_hist=dict(sorted(hdist.items(), key=lambda kv: int(kv[0]))),
        mean_distinct_3d_per_record=tot["n_distinct_3d_total"] / float(n_rec) if n_rec else None,
        fraction_records_with_all_slots_distinct=hdist.get(str(n_slots_3d), 0) / float(n_rec) if n_rec else None,
        conformer_attempts=attempts, shards_without_attempt_counters=attempts_missing)

    # validation coverage
    res = validation.get("results", [])
    n_stored = sum(r.get("n_records", 0) for r in res)
    n_checked = sum(r.get("n_checked", 0) for r in res)
    shortfall = [r.get("lmdb") for r in res
                 if r.get("n_checked", 0) < min(criteria["min_validation_records_per_shard"], r.get("n_records", 0))]
    totals = validation.get("totals", {})
    rep["validation"] = {
        "mode": "full" if n_stored and n_checked == n_stored else "sampled",
        "n_lmdb_checked": len(res), "n_lmdb_in_manifest": len(manifest["shards"]),
        "n_records_stored": n_stored, "n_records_checked": n_checked,
        "coverage_fraction": n_checked / float(n_stored) if n_stored else None,
        "min_checked_per_shard": min((r.get("n_checked", 0) for r in res), default=0),
        "shards_below_min_depth": len(shortfall),
        "fallback_audit": bool(validation.get("fallback_audit")),
        "n_fallback_audited": totals.get("n_audited", 0),
        "n_fallback_mismatches": totals.get("n_accounting_mismatch", 0),
        "n_problems": validation.get("n_problems")}

    # criteria
    c, f = criteria, []
    e, s4, v = rep["enumeration"], rep["stage04"], rep["validation"]
    if e["failure_fraction"] is not None and e["failure_fraction"] > c["max_enumeration_failure_fraction"]:
        f.append("Ugi failure fraction {:.4f} > {}".format(e["failure_fraction"], c["max_enumeration_failure_fraction"]))
    if s4["skipped_fraction"] is None or s4["skipped_fraction"] > c["max_skipped_fraction"]:
        f.append("skipped fraction {} > {}".format(s4["skipped_fraction"], c["max_skipped_fraction"]))
    if s4["n_unsupported_atom_records"] > c["max_unsupported_atom_records"]:
        f.append("{} records skipped for atoms outside dict.txt (max {})".format(
            s4["n_unsupported_atom_records"], c["max_unsupported_atom_records"]))
    if (s4["records_with_2d_fill_fraction"] or 0) > c["max_records_with_2d_fill_fraction"]:
        f.append("records with a 2D fill-in {:.4f} > {}".format(s4["records_with_2d_fill_fraction"],
                                                                 c["max_records_with_2d_fill_fraction"]))
    if (s4["fill_2d_slot_fraction"] or 0) > c["max_2d_fill_slot_fraction"]:
        f.append("2D fill-in slot fraction {:.4f} > {}".format(s4["fill_2d_slot_fraction"], c["max_2d_fill_slot_fraction"]))
    if (v["n_problems"] or 0) > c["max_validation_problems"]:
        f.append("validation problems {} > {}".format(v["n_problems"], c["max_validation_problems"]))
    if v["n_lmdb_checked"] != v["n_lmdb_in_manifest"]:
        f.append("validation checked {} of {} shards".format(v["n_lmdb_checked"], v["n_lmdb_in_manifest"]))
    if v["shards_below_min_depth"]:
        f.append("{} shard(s) validated below the minimum depth of {} records".format(
            v["shards_below_min_depth"], c["min_validation_records_per_shard"]))
    if c["require_full_fallback_audit"] and (not v["fallback_audit"] or v["n_fallback_audited"] != v["n_records_checked"]
                                             or v["n_fallback_mismatches"]):
        f.append("fallback audit incomplete or mismatched ({} audited of {} checked, {} mismatches)".format(
            v["n_fallback_audited"], v["n_records_checked"], v["n_fallback_mismatches"]))
    rep["failures"] = f
    rep["criteria_enforced"] = not rep["smoke"]
    rep["passed"] = (not f) or rep["smoke"]
    return rep


def to_markdown(rep):
    e, d, s, v = rep["enumeration"], rep["dedup"], rep["stage04"], rep["validation"]
    pct = lambda x: "n/a" if x is None else "{:.3%}".format(x)   # noqa: E731
    lines = ["# Lipid library quality report", "",
             "**Verdict:** {} ({}criteria enforced)".format(
                 "PASS" if rep["passed"] and not rep["failures"] else ("PASS (smoke, not enforced)" if rep["passed"] else "FAIL"),
                 "" if rep["criteria_enforced"] else "smoke library: NOT "), ""]
    for x in rep["failures"]:
        lines.append("* FAILED: " + x)
    lines += ["", "| Quantity | Value |", "|---|---|",
              "| Ugi-4CR combinations | {} |".format(e["n_combinations"]),
              "| products / Ugi failures | {} / {} ({}) |".format(e["n_products"], e["n_failures"], pct(e["failure_fraction"])),
              "| duplicate product rows dropped | {} |".format(d["n_duplicate_rows_dropped"]),
              "| stage-04 input rows / accepted records / skipped | {} / {} / {} ({}) |".format(
                  s["n_input_rows"], s["n_records"], s["n_skipped"], pct(s["skipped_fraction"])),
              "| skipped by category | {} |".format(json.dumps(s["skip_by_category"])),
              "| records with >= 1 2D fill-in slot | {} ({}) |".format(s["n_records_with_2d_fill"], pct(s["records_with_2d_fill_fraction"])),
              "| 2D fill-in slots / all 3D slots | {} ({}) |".format(s["n_2d_filled_total"], pct(s["fill_2d_slot_fraction"])),
              "| successful 3D embeddings per record (hist) | {} |".format(json.dumps(s["n_3d_success_hist"])),
              "| DISTINCT 3D conformers per record (hist) | {} |".format(json.dumps(s["n_distinct_3d_hist"])),
              "| mean distinct 3D / record; all {} distinct | {:.3f}; {} |".format(
                  s["slots_3d_per_record"], s["mean_distinct_3d_per_record"] or 0, pct(s["fraction_records_with_all_slots_distinct"])),
              "| ETKDG/MMFF attempt counters | {} |".format(json.dumps(s["conformer_attempts"])),
              "| validation mode / coverage | {} / {} of {} records ({}) |".format(
                  v["mode"], v["n_records_checked"], v["n_records_stored"], pct(v["coverage_fraction"])),
              "| shards validated / min records per shard | {} of {} / {} |".format(
                  v["n_lmdb_checked"], v["n_lmdb_in_manifest"], v["min_checked_per_shard"]),
              "| fallback audit: audited / mismatches | {} / {} |".format(v["n_fallback_audited"], v["n_fallback_mismatches"]),
              "", "Skip reasons: `{}`".format(json.dumps(s["skip_reasons"])),
              "", "Ugi failure reasons: `{}`".format(json.dumps(e["failure_reasons"]))]
    return "\n".join(lines) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("lmdb_dir")
    ap.add_argument("--enum-dir", required=True)
    ap.add_argument("--dedup-dir", required=True)
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--criteria-json", default=None)
    ns = ap.parse_args(argv)
    crit, source = load_criteria(ns.criteria_json)
    rep = build_report(ns.lmdb_dir, ns.enum_dir, ns.dedup_dir, crit, ns.workers)
    rep["criteria_source"] = source
    io_utils.atomic_write_json(os.path.join(ns.lmdb_dir, REPORT), rep)
    io_utils.atomic_write_text(os.path.join(ns.lmdb_dir, "quality_report.md"), to_markdown(rep))
    print(to_markdown(rep))
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
