#!/usr/bin/env python
"""Stage 04 in ONE allocation: a dynamic per-shard queue over the unchanged writer.

    python -m lipid_library.stage04_pool ENUM_DIR -o LMDB_DIR <the stage-04 writer options> \
        --workers 250 --stride 1000 [--deadline-epoch T --margin-min 45] [--dry-run]

What it does NOT change: chemistry, conformer policy (conformers.py), the
writer configuration fingerprint, the 03b partition, the shard layout, the
per-shard LMDB/receipt format (lmdb_writer.write_shard), or stage 05. A shard
written here is byte-for-byte the same kind of shard an array task writes, and
the same `lmdb_writer --finalize` verifies it.

Why (replaces the v1 `04_conformers_250cpu.sbatch`, which ran
`seq 0 999 | xargs -P 250 lmdb_writer --shard i --num-shards 1000`):
  * work unit = ONE shard (~5,000 molecules), not one task of 3-4 shards, so
    the tail of the run is at most one shard long instead of 3-4;
  * each shard runs in a fresh spawned process (max_tasks_per_child=1):
    RDKit memory cannot accumulate and a crash loses only that shard;
  * existing shards are re-verified (receipt + config/input fingerprint +
    LMDB sha256) inside the workers, i.e. in parallel, and skipped;
  * the configuration and array-geometry locks are taken ONCE, in this
    process, before any worker starts (no read-before-write race);
  * the whole output directory is locked EXCLUSIVELY (dirlock.py): a second
    pool or any array task on the same directory refuses to start;
  * no new shard is started when it could not finish before the SLURM time
    limit (--deadline-epoch, margin); SIGUSR1/SIGTERM stop dispatching;
  * progress (done / pending / running / failed, measured s/molecule, ETA) is
    written atomically to LMDB_DIR/stage04_progress.json every --progress-sec;
  * a disk-space preflight refuses to start when the remaining shards would
    not fit (measured bytes/record from finished shards, else an assumption).

Exit codes: 0 every shard complete; 3 stopped early (deadline/signal) with
work left -- resubmit the same command; 1 a shard failed or a check refused.
"""
import argparse
import concurrent.futures as cf
import json
import logging
import multiprocessing
import os
import shutil
import signal
import socket
import sys
import time
from types import SimpleNamespace

from . import io_utils, provenance
from . import lmdb_writer as lw
from .dirlock import DirLock, LockBusy

logger = logging.getLogger(__name__)

PROGRESS_NAME = "stage04_progress.json"
WRITER_KEYS = ["n_3d", "store_2d", "max_try", "max_iterations", "seed_start", "max_atoms", "only_polar",
               "allow_2d_only", "map_size_gb", "commit_every", "dict_path", "no_verify_hash"]
EXIT_INCOMPLETE = 3

_STOP = {"reason": None}


def _on_signal(signum, _frame):
    _STOP["reason"] = "signal {}".format(signal.Signals(signum).name)
    logger.warning("received %s: no new shards will be started", _STOP["reason"])


# --------------------------------------------------------------------------- worker side
def _init_worker():
    # Workers ignore the stop signals: the parent decides; SLURM's final SIGKILL ends them.
    for s in ("SIGUSR1", "SIGTERM", "SIGINT"):
        if hasattr(signal, s):
            try:
                signal.signal(getattr(signal, s), signal.SIG_IGN)
            except (OSError, ValueError):
                pass
    for v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
        os.environ[v] = "1"


def run_one_shard(out_dir, entry, opts_dict, config_fp):
    """Verify-or-build one shard. Returns a small summary dict (picklable)."""
    opts = SimpleNamespace(**opts_dict)
    opts.dict_symbols = lw.load_dictionary_symbols(opts.dict_path) if opts.dict_path else None
    sid = entry["shard_id"]
    t0 = time.time()
    if lw.shard_is_complete(out_dir, sid, not opts.no_verify_hash, config_fp, entry["input_fingerprint"]):
        return {"shard_id": sid, "status": "verified", "seconds": round(time.time() - t0, 3)}
    rows = lw.read_shard_input(out_dir, entry, not opts.no_verify_hash)
    r = lw.write_shard(rows, out_dir, sid, opts, config_fp)
    size = os.path.getsize(os.path.join(lw._shard_dir(out_dir, sid), "train.lmdb"))
    return {"shard_id": sid, "status": "written", "seconds": r["seconds"], "n_input_rows": r["n_input_rows"],
            "n_records": r["n_records"], "n_skipped": r["n_skipped"], "lmdb_bytes": size,
            "n_2d_filled_total": r["n_2d_filled_total"], "n_records_with_2d_fill": r["n_records_with_2d_fill"]}


def _peak_child_rss_mb():
    """Largest resident set of any finished worker process (Linux ru_maxrss is KiB); None elsewhere."""
    try:
        import resource

        return round(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024.0, 1)
    except (ImportError, AttributeError, ValueError):
        return None


# --------------------------------------------------------------------------- planning helpers
def receipt_state(out_dir, entries, config_fp):
    """Cheap pre-scan (no hashing): which shards have a receipt for this config and input."""
    have, measured_bytes, measured_records = [], 0, 0
    for e in entries:
        r = lw.read_receipt(out_dir, e["shard_id"])
        if (r and r.get("config_fingerprint") == config_fp
                and r.get("input_fingerprint") == e["input_fingerprint"]):
            have.append(e["shard_id"])
            lp = os.path.join(lw._shard_dir(out_dir, e["shard_id"]), "train.lmdb")
            if os.path.isfile(lp) and r.get("n_records"):
                measured_bytes += os.path.getsize(lp)
                measured_records += r["n_records"]
    return have, measured_bytes, measured_records


def disk_preflight(out_dir, n_rows_left, bytes_per_record, factor):
    need = int(n_rows_left * bytes_per_record * factor)
    free = shutil.disk_usage(out_dir).free
    return {"free_bytes": free, "need_bytes": need, "ok": free >= need,
            "bytes_per_record": bytes_per_record, "factor": factor}


def write_progress(out_dir, state):
    state = dict(state, updated=time.strftime("%Y-%m-%d %H:%M:%S"), updated_epoch=time.time())
    io_utils.atomic_write_json(os.path.join(out_dir, PROGRESS_NAME), state)


# --------------------------------------------------------------------------- main
def build_parser():
    ap = lw.build_parser()
    ap.description = __doc__.splitlines()[0]
    ap.set_defaults(workers=max(1, (os.cpu_count() or 2) - 1))   # --workers comes from lmdb_writer
    ap.add_argument("--stride", type=int, default=1000,
                    help="historical stage-04 array stride, locked for resubmit lists (default 1000)")
    ap.add_argument("--deadline-epoch", type=float, default=None,
                    help="unix time of the SLURM time limit; no shard starts that cannot end before it")
    ap.add_argument("--margin-min", type=float, default=45.0)
    ap.add_argument("--sec-per-molecule-hint", type=float, default=3.0,
                    help="per-molecule seconds assumed for deadline gating until shards are measured")
    ap.add_argument("--bytes-per-record", type=float, default=26000.0,
                    help="assumed LMDB bytes/record for the disk preflight until shards are measured")
    ap.add_argument("--min-free-factor", type=float, default=1.15)
    ap.add_argument("--skip-disk-check", action="store_true")
    ap.add_argument("--progress-sec", type=float, default=60.0)
    ap.add_argument("--max-shards", type=int, default=None, help="testing: stop after this many shards")
    ap.add_argument("--dry-run", action="store_true", help="checks + plan only; write nothing")
    return ap


def main(argv=None):
    ns = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="[stage04 %(asctime)s] %(message)s", datefmt="%H:%M:%S")
    for bad, why in ((ns.shard is not None, "--shard"), (ns.finalize, "--finalize"), (ns.plan, "--plan"),
                     (ns.partition, "--partition")):
        if bad:
            raise SystemExit("ERROR: {} is not a pool option (use lmdb_writer)".format(why))
    if ns.workers < 1 or ns.stride < 1:
        raise SystemExit("ERROR: --workers and --stride must be >= 1")
    ns.dict_symbols = lw.load_dictionary_symbols(ns.dict_path) if ns.dict_path else None

    lock = DirLock(ns.out_dir, shared=False, label="stage04_pool")
    try:
        if not ns.dry_run:
            lock.acquire()
    except LockBusy as exc:
        raise SystemExit("ERROR: {}".format(exc))
    try:
        return _run(ns)
    finally:
        lock.release()


def _run(ns):
    # 1. configuration, array geometry and partition: once, before any worker
    try:
        config = lw.writer_config(ns, ns.products_dir)
        if ns.dry_run:
            locked = provenance.read_config(ns.out_dir, "lmdb_writer")
            fp = provenance.fingerprint(config)
            if locked is not None and locked["fingerprint"] != fp:
                raise provenance.StaleOutputError("lmdb_writer_config.json differs from these options")
        else:
            fp = provenance.lock_config(ns.out_dir, "lmdb_writer", config)
            lw.lock_array_geometry(ns.out_dir, ns.stride)
        index = lw.load_partition(ns.out_dir, ns, ns.products_dir)
    except (lw.PartitionError, provenance.StaleOutputError) as exc:
        raise SystemExit("ERROR: {}".format(exc))
    entries = sorted(index["shards"], key=lambda e: e["shard_id"])
    logger.info("config %s%s | %d shards, %d input rows | workers %d | host %s",
                fp[:16], " (SMOKE)" if config["smoke"] else "", len(entries), index["n_input_rows"],
                ns.workers, socket.gethostname())

    have, mbytes, mrecs = receipt_state(ns.out_dir, entries, fp)
    have_set = set(have)
    rows_left = sum(e["n_input_rows"] for e in entries if e["shard_id"] not in have_set)
    bpr = (mbytes / float(mrecs)) if mrecs else ns.bytes_per_record
    disk = disk_preflight(ns.out_dir, rows_left, bpr, ns.min_free_factor)
    logger.info("receipts present for %d/%d shards (re-verified by the workers); %d rows left; disk: "
                "%.1f GB free, ~%.1f GB needed (%.0f B/record %s)", len(have), len(entries), rows_left,
                disk["free_bytes"] / 1e9, disk["need_bytes"] / 1e9, bpr, "measured" if mrecs else "assumed")
    if not disk["ok"] and not ns.skip_disk_check:
        raise SystemExit("ERROR: not enough free disk for the remaining shards (see above); free space "
                         "or pass --skip-disk-check after checking the estimate")
    if ns.dry_run:
        print(json.dumps({"dry_run": True, "n_shards": len(entries), "receipts_present": len(have),
                          "rows_left": rows_left, "disk": disk, "workers": ns.workers,
                          "config_fingerprint": fp}, indent=2))
        return 0

    for s in ("SIGUSR1", "SIGTERM"):
        if hasattr(signal, s):
            signal.signal(getattr(signal, s), _on_signal)

    # Unverified shards first (real work), receipts last (verification only).
    queue = [e for e in entries if e["shard_id"] not in have_set] + [e for e in entries if e["shard_id"] in have_set]
    if ns.max_shards is not None:
        queue = queue[: ns.max_shards]
    opts_dict = {k: getattr(ns, k) for k in WRITER_KEYS}
    state = {"job_id": os.environ.get("SLURM_JOB_ID"), "host": socket.gethostname(), "workers": ns.workers,
             "config_fingerprint": fp, "n_shards": len(entries), "verified": 0, "written": 0, "failed": [],
             "running": 0, "pending": len(queue), "stopped": None, "started": time.strftime("%Y-%m-%d %H:%M:%S"),
             "measured_sec_per_molecule_cpu": None, "eta_hours": None,
             "cpus_visible": os.cpu_count(),
             "cpus_usable": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
             "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK")}
    secs, mols = 0.0, 0
    t_start = time.time()
    ctx = multiprocessing.get_context("spawn")
    kwargs = {"max_workers": ns.workers, "mp_context": ctx, "initializer": _init_worker}
    if sys.version_info >= (3, 11):
        kwargs["max_tasks_per_child"] = 1
    running = {}
    last_progress = 0.0
    with cf.ProcessPoolExecutor(**kwargs) as pool:
        qi = 0
        while qi < len(queue) or running:
            # dispatch
            while qi < len(queue) and len(running) < ns.workers and _STOP["reason"] is None:
                e = queue[qi]
                if ns.deadline_epoch and e["shard_id"] not in have_set:
                    spm = (secs / mols) if mols else ns.sec_per_molecule_hint
                    need = e["n_input_rows"] * spm * 1.25
                    if time.time() + need > ns.deadline_epoch - 60.0 * ns.margin_min:
                        _STOP["reason"] = "deadline"
                        logger.warning("deadline: a new shard needs ~%.1f h; not starting more", need / 3600)
                        break
                fut = pool.submit(run_one_shard, ns.out_dir, e, opts_dict, fp)
                running[fut] = e
                qi += 1
            if not running:
                break
            done, _ = cf.wait(list(running), timeout=5.0, return_when=cf.FIRST_COMPLETED)
            for fut in done:
                e = running.pop(fut)
                try:
                    r = fut.result()
                except Exception as exc:          # noqa: BLE001 - recorded, run continues
                    state["failed"].append({"shard_id": e["shard_id"], "error": "{}: {}".format(
                        type(exc).__name__, exc)[:500]})
                    logger.error("shard %d FAILED: %s: %s", e["shard_id"], type(exc).__name__, exc)
                    continue
                state[r["status"]] += 1
                if r["status"] == "written":
                    secs += r["seconds"]
                    mols += r["n_input_rows"]
                    logger.info("shard %d written: %d records, %d skipped, %d with 2D fill, %.0fs",
                                r["shard_id"], r["n_records"], r["n_skipped"], r["n_records_with_2d_fill"],
                                r["seconds"])
            now = time.time()
            if now - last_progress >= ns.progress_sec or not running:
                last_progress = now
                left_rows = sum(e["n_input_rows"] for e in queue[qi:] if e["shard_id"] not in have_set)
                spm = (secs / mols) if mols else None
                state.update(running=len(running), pending=len(queue) - qi, stopped=_STOP["reason"],
                             elapsed_hours=round((now - t_start) / 3600, 3),
                             measured_sec_per_molecule_cpu=round(spm, 4) if spm else None,
                             eta_hours=round(left_rows * spm / ns.workers / 3600, 2) if spm else None)
                write_progress(ns.out_dir, state)
    state.update(running=0, pending=len(queue) - qi, stopped=_STOP["reason"],
                 finished=time.strftime("%Y-%m-%d %H:%M:%S"), elapsed_hours=round((time.time() - t_start) / 3600, 4),
                 molecules_written=mols, cpu_seconds_written=round(secs, 1),
                 peak_worker_rss_mb=_peak_child_rss_mb())
    complete = state["verified"] + state["written"]
    state["all_complete"] = (complete == len(entries) and not state["failed"])
    write_progress(ns.out_dir, state)
    io_utils.atomic_write_json(os.path.join(ns.out_dir, "stage04_run-{}.json".format(
        os.environ.get("SLURM_JOB_ID", "local-{}".format(os.getpid())))), state)
    logger.info("done: %d verified + %d written of %d shards, %d failed, stopped=%s",
                state["verified"], state["written"], len(entries), len(state["failed"]), state["stopped"])
    if state["failed"]:
        return 1
    if not state["all_complete"]:
        logger.warning("incomplete: resubmit stage 04 (finished shards are verified and skipped)")
        return EXIT_INCOMPLETE
    logger.info("stage 04 complete: run stage 05 (finalize)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
