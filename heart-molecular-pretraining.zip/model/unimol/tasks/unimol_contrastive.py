# Copyright (c) DP Technology.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
#
# Source: LUMI-lab model/unimol/tasks/unimol_contrastive.py
#   (https://github.com/bowenli-lab/LUMI-lab, commit 611e02b), itself derived
#   from Uni-Mol unimol/tasks/unimol.py (MIT, DP Technology).
# HEART modifications (see model/pretrain/IMPLEMENTATION_MAP.md, patch P3):
#   * --contrastive-view-mode {independent,identical}. With the stock Uni-Mol
#     data modules, every random choice (conformer, mask, noise) is seeded by
#     (seed, epoch, index) and LRU-cached, so LUMI's two calls to ds[index]
#     return byte-identical "views" and the contrastive positives differ only
#     by dropout. "identical" reproduces that upstream behaviour exactly;
#     "independent" (HEART default) builds the second view with a different
#     seed so the two views use independently sampled conformers, masks and
#     coordinate noise.
#   * The LMDB reader and Add2DConformerDataset are built once and shared by
#     both views (one LMDB read + one 2D embedding per molecule).
#   * --invalid-smiles-policy / --max-invalid-smiles-fraction (patch P6):
#     handling of records whose SMILES cannot give an aligned 2D conformer.

import logging
import os
from collections import OrderedDict

import torch
from torch.utils.data.dataloader import default_collate
import numpy as np
from unicore.data import (
    Dictionary,
    NestedDictionaryDataset,
    AppendTokenDataset,
    PrependTokenDataset,
    RightPadDataset,
    EpochShuffleDataset,
    TokenizeDataset,
    RightPadDataset2D,
    FromNumpyDataset,
    RawArrayDataset,
    UnicoreDataset
)
from unicore.data.nested_dictionary_dataset import _flatten, _unflatten
from unimol.data import (
    KeyDataset,
    ConformerSampleDataset,
    DistanceDataset,
    EdgeTypeDataset,
    MaskPointsDataset,
    RemoveHydrogenDataset,
    AtomTypeDataset,
    NormalizeDataset,
    CroppingDataset,
    RightPadDatasetCoord,
    Add2DConformerDataset,
    LMDBDataset,
)
from unicore.tasks import UnicoreTask, register_task


logger = logging.getLogger(__name__)


@register_task("unimol_contrastive")
class UniMolTaskContrastive(UnicoreTask):
    """Task for training transformer auto-encoder models."""

    @staticmethod
    def add_args(parser):
        """Add task-specific arguments to the parser."""
        parser.add_argument(
            "data",
            help="colon separated path to data directories list, \
                            will be iterated upon during epochs in round-robin manner",
        )
        parser.add_argument(
            "--mask-prob",
            default=0.15,
            type=float,
            help="probability of replacing a token with mask",
        )
        parser.add_argument(
            "--leave-unmasked-prob",
            default=0.05,
            type=float,
            help="probability that a masked token is unmasked",
        )
        parser.add_argument(
            "--random-token-prob",
            default=0.05,
            type=float,
            help="probability of replacing a token with a random token",
        )
        parser.add_argument(
            "--noise-type",
            default="uniform",
            choices=["trunc_normal", "uniform", "normal", "none"],
            help="noise type in coordinate noise",
        )
        parser.add_argument(
            "--noise",
            default=1.0,
            type=float,
            help="coordinate noise for masked atoms",
        )
        parser.add_argument(
            "--remove-hydrogen",
            action="store_true",
            help="remove hydrogen atoms",
        )
        parser.add_argument(
            "--remove-polar-hydrogen",
            action="store_true",
            help="remove polar hydrogen atoms",
        )
        parser.add_argument(
            "--max-atoms",
            type=int,
            default=256,
            help="selected maximum number of atoms in a molecule",
        )
        parser.add_argument(
            "--dict-name",
            default="dict.txt",
            help="dictionary file",
        )
        parser.add_argument(
            "--only-polar",
            default=1,
            type=int,
            help="1: only polar hydrogen ; -1: all hydrogen ; 0: remove all hydrogen ",
        )
        parser.add_argument(
            "--contrastive-loss",
            default=1.0,
            type=float,
            help="weights of contrastive loss",
        )
        parser.add_argument(
            "--contrastive-view-mode",
            default="independent",
            choices=["independent", "identical"],
            help="HEART: 'independent' samples conformer/mask/noise separately "
            "for the two contrastive views; 'identical' reproduces LUMI with "
            "stock Uni-Mol data modules (views differ only by dropout)",
        )
        parser.add_argument(
            "--view-seed-offset",
            default=1000003,
            type=int,
            help="HEART: seed offset for the second view when "
            "--contrastive-view-mode=independent",
        )
        parser.add_argument(
            "--invalid-smiles-policy",
            default="skip-2d",
            choices=["skip-2d", "error"],
            help="HEART P6: a record whose SMILES RDKit rejects, or whose AddHs "
            "atoms differ from the record, gets no 2D conformer and keeps its "
            "stored 3D conformers ('skip-2d', logged), or stops training ('error')",
        )
        parser.add_argument(
            "--max-invalid-smiles-fraction",
            default=0.01,
            type=float,
            help="HEART P6: stop training if more than this fraction of the "
            "records processed (after the first 10000) had no usable 2D conformer",
        )


    def __init__(self, args, dictionary):
        super().__init__(args)
        self.dictionary = dictionary
        self.seed = args.seed
        # add mask token
        self.mask_idx = dictionary.add_symbol("[MASK]", is_special=True)
        if self.args.only_polar > 0:
            self.args.remove_polar_hydrogen = True
        elif args.only_polar < 0:
            self.args.remove_polar_hydrogen = False
        else:
            self.args.remove_hydrogen = True

    @classmethod
    def setup_task(cls, args, **kwargs):
        dictionary = Dictionary.load(os.path.join(args.data, args.dict_name))
        logger.info("dictionary: {} types".format(len(dictionary)))
        return cls(args, dictionary)

    def load_dataset(self, split, combine=False, **kwargs):
        """Load a given dataset split.
        Args:
            split (str): name of the split (e.g., train, valid, test)
        """
        split_path = os.path.join(self.args.data, split + ".lmdb")

        raw_dataset = LMDBDataset(split_path)
        if self.args.mode == "train":
            raw_dataset = Add2DConformerDataset(
                raw_dataset, "smi", "atoms", "coordinates",
                invalid_policy=getattr(self.args, "invalid_smiles_policy", "skip-2d"),
                max_invalid_fraction=getattr(self.args, "max_invalid_smiles_fraction", 0.01),
            )

        def one_dataset(raw_dataset, coord_seed, mask_seed):
            smi_dataset = KeyDataset(raw_dataset, "smi")
            dataset = ConformerSampleDataset(
                raw_dataset, coord_seed, "atoms", "coordinates"
            )
            dataset = AtomTypeDataset(raw_dataset, dataset)
            dataset = RemoveHydrogenDataset(
                dataset,
                "atoms",
                "coordinates",
                self.args.remove_hydrogen,
                self.args.remove_polar_hydrogen,
            )
            dataset = CroppingDataset(
                dataset, self.seed, "atoms", "coordinates", self.args.max_atoms
            )
            dataset = NormalizeDataset(dataset, "coordinates", normalize_coord=True)
            token_dataset = KeyDataset(dataset, "atoms")
            token_dataset = TokenizeDataset(
                token_dataset, self.dictionary, max_seq_len=self.args.max_seq_len
            )
            coord_dataset = KeyDataset(dataset, "coordinates")
            expand_dataset = MaskPointsDataset(
                token_dataset,
                coord_dataset,
                self.dictionary,
                pad_idx=self.dictionary.pad(),
                mask_idx=self.mask_idx,
                noise_type=self.args.noise_type,
                noise=self.args.noise,
                seed=mask_seed,
                mask_prob=self.args.mask_prob,
                leave_unmasked_prob=self.args.leave_unmasked_prob,
                random_token_prob=self.args.random_token_prob,
            )

            def PrependAndAppend(dataset, pre_token, app_token):
                dataset = PrependTokenDataset(dataset, pre_token)
                return AppendTokenDataset(dataset, app_token)

            encoder_token_dataset = KeyDataset(expand_dataset, "atoms")
            encoder_target_dataset = KeyDataset(expand_dataset, "targets")
            encoder_coord_dataset = KeyDataset(expand_dataset, "coordinates")

            src_dataset = PrependAndAppend(
                encoder_token_dataset, self.dictionary.bos(), self.dictionary.eos()
            )
            tgt_dataset = PrependAndAppend(
                encoder_target_dataset, self.dictionary.pad(), self.dictionary.pad()
            )
            encoder_coord_dataset = PrependAndAppend(encoder_coord_dataset, 0.0, 0.0)
            encoder_distance_dataset = DistanceDataset(encoder_coord_dataset)

            edge_type = EdgeTypeDataset(src_dataset, len(self.dictionary))
            coord_dataset = FromNumpyDataset(coord_dataset)
            coord_dataset = PrependAndAppend(coord_dataset, 0.0, 0.0)
            distance_dataset = DistanceDataset(coord_dataset)
            return {
                "src_tokens": RightPadDataset(
                    src_dataset,
                    pad_idx=self.dictionary.pad(),
                ),
                "src_coord": RightPadDatasetCoord(
                    encoder_coord_dataset,
                    pad_idx=0,
                ),
                "src_distance": RightPadDataset2D(
                    encoder_distance_dataset,
                    pad_idx=0,
                ),
                "src_edge_type": RightPadDataset2D(
                    edge_type,
                    pad_idx=0,
                ),
            }, {
                "tokens_target": RightPadDataset(
                    tgt_dataset, pad_idx=self.dictionary.pad()
                ),
                "distance_target": RightPadDataset2D(distance_dataset, pad_idx=0),
                "coord_target": RightPadDatasetCoord(coord_dataset, pad_idx=0),
                "smi_name": RawArrayDataset(smi_dataset),
            }

        net_input, target = one_dataset(raw_dataset, self.args.seed, self.args.seed)
        views = [{"net_input": net_input, "target": target}]
        if getattr(self.args, "contrastive_view_mode", "identical") == "independent":
            view_seed = self.args.seed + self.args.view_seed_offset
            net_input_1, target_1 = one_dataset(raw_dataset, view_seed, view_seed)
            views.append({"net_input": net_input_1, "target": target_1})
        dataset = PairSampledNestedDictionaryDataset(*views)
        if split in ["train", "train.small"]:
            dataset = EpochShuffleDataset(dataset, len(dataset), self.args.seed)
        self.datasets[split] = dataset

    def build_model(self, args):
        from unicore import models

        model = models.build_model(args, self)
        return model

    def disable_shuffling(self) -> bool:
        return True
    
class PairSampledNestedDictionaryDataset(UnicoreDataset):
    def __init__(self, defn, defn_view_1=None):
        super().__init__()
        self.defn = _flatten(defn)
        # HEART: optional second pipeline for view_1 (same keys, different seeds).
        self.defn_view_1 = _flatten(defn_view_1) if defn_view_1 is not None else self.defn
        assert list(self.defn_view_1.keys()) == list(self.defn.keys())
        first = None
        for v in list(self.defn.values()) + list(self.defn_view_1.values()):
            if not isinstance(
                v,
                (
                    UnicoreDataset,
                    torch.utils.data.Dataset,
                ),
            ):
                raise ValueError("Expected Dataset but found: {}".format(v.__class__))
            first = first or v
            if len(v) > 0:
                assert len(v) == len(first), "dataset lengths must match"

        self._len = len(first)

    def __getitem__(self, index):
        """This method samples two molecules with different views from the same molecule.
        """
        
        # return OrderedDict((k, ds[index]) for k, ds in self.defn.items())
        return_dict = OrderedDict()
        for i, defn in enumerate((self.defn, self.defn_view_1)):
            return_dict[f"view_{i}"] = OrderedDict((k, ds[index]) for k, ds in defn.items())
        
        return return_dict

    def __len__(self):
        return self._len


    def collater(self, samples):
        """Merge a list of samples to form a mini-batch, this collator processes
        two views of the the sample molecules

        Args:
            samples (List[dict]): samples to collate

        Returns:
            dict: a mini-batch suitable for forwarding with a Model
        """
        if len(samples) == 0:
            return {}
        sample = OrderedDict()
        for k, ds in self.defn.items():
            try:
                # sample[k] = ds.collater([s[k] for s in samples])
                sample[k] = ds.collater([s[f"view_{i}"][k] for i in range(2) for s in samples])
            except NotImplementedError:
                # sample[k] = default_collate([s[k] for s in samples])
                sample[k] = default_collate([s[f"view_{i}"][k] for i in range(2) for s in samples])
        return _unflatten(sample)


    @property
    def supports_prefetch(self):
        """Whether this dataset supports prefetching."""
        return any(ds.supports_prefetch for ds in self._all_datasets())

    def prefetch(self, indices):
        """Prefetch the data required for this epoch."""
        for ds in self._all_datasets():
            if getattr(ds, "supports_prefetch", False):
                ds.prefetch(indices)

    @property
    def can_reuse_epoch_itr_across_epochs(self):
        return all(ds.can_reuse_epoch_itr_across_epochs for ds in self._all_datasets())

    def set_epoch(self, epoch):
        super().set_epoch(epoch)
        for ds in self._all_datasets():
            ds.set_epoch(epoch)

    def _all_datasets(self):
        if self.defn_view_1 is self.defn:
            return list(self.defn.values())
        return list(self.defn.values()) + list(self.defn_view_1.values())
