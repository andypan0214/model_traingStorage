# HEART Project-path migration — active Home checkout

This is a **new directory deployment** from the previously supplied code ZIP.
No GitHub push/pull, LMDB rewrite, checkpoint rewrite, or training job is needed.

- **New production code**: `/home/ypan/heart_liver/model_train/heart-molecular-pretraining` (no `-v2` suffix)
- **Preserve rollback**: `/home/ypan/heart_liver/model_train/heart-molecular-pretraining-v2`
- **General train/valid LMDBs**: `/project/yli4/ypan/UniMolReference/ligand_data/ligands`
- **Lipid library**: `/project/yli4/ypan/lipid_library` (Stage 01-04 DONE, Stage 05 QC FAILED)
- **General + continual outputs**: `/project/yli4/ypan/runs/h200`
- **General + continual Slurm stdout/stderr**: `/project/yli4/ypan/runs/h200/slurm`
- **Library pipeline logs**: `/project/yli4/ypan/lipid_library/logs` (intentionally separate)
- **Uni-Core, Conda**: Home code paths are unchanged.

The preserved internal symbols `heart_v2`, `heart_v2.yaml`, and `HEART_V2_*`
are **software interface names**, not filesystem directory names. Renaming them
is out of scope and would risk unrelated changes.

## Deployment

Upload `heart-molecular-pretraining_ProjectReady.zip` to your HPC Home directory
and extract it under `/home/ypan/heart_liver/model_train/`:

```bash
cd /home/ypan/heart_liver/model_train
# Confirm that neither existing checkout will be overwritten.
test ! -e heart-molecular-pretraining || { echo 'Destination already exists; stop'; exit 1; }
unzip ~/heart-molecular-pretraining_ProjectReady.zip
# This produces heart-molecular-pretraining/; the -v2 checkout is untouched.
mkdir -p /project/yli4/ypan/runs/h200/slurm
cd heart-molecular-pretraining
bin/heart baseline
bin/heart check
python scripts/verify_project_layout.py
```

If any acceptance check fails, **do not delete** the `-v2` checkout, overwrite
Project data, or launch any Stage 05/06 job. The original Stage 05 QC failure is
an independent scientific issue and has **not** been relaxed or fixed here.

## Files intentionally migrated

General scripts `pretrain_heart-h200.sh`, `pretrain_heart.sh`, `pretrain_smoke.sh`,
shared `heart_lib.sh`, related `configs/`, baseline-verification tests and active
documentation now point to Home source + Project data/checkpoints/logs.
`continual_pretrain_heart-h200.sh` and `config/heart_v2.yaml` use the same roots.
The four-test Notebook is in `model/pretrain/notebooks/`.

The historical upstream protected-file Git blob hashes are **preserved** in
`config/general_baseline_manifest.json`; exact-hash allowlisted path-only
migrations are recorded separately in that manifest, and reported explicitly by
`bin/heart baseline`. This makes the deployment edits auditable rather than
pretending General Pretraining remained byte-for-byte identical.

**Never rerun Stages 01–04 or overwrite the original quality_report.json.**
