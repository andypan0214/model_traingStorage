# Deployment-path audit (2026-11-16)

- **Active code:** `/home/ypan/heart_liver/model_train/heart-molecular-pretraining`
- **Preserve rollback:** `/home/ypan/heart_liver/model_train/heart-molecular-pretraining-v2`
- **Reference data:** `/project/yli4/ypan/UniMolReference/ligand_data/ligands`
- **Lipid production shards:** `/project/yli4/ypan/lipid_library/lmdb`
- **All general+continual checkpoints:** `/project/yli4/ypan/runs/h200/{smoke,full,continual}`
- **All general+continual Slurm stdout/stderr:** `/project/yli4/ypan/runs/h200/slurm/%x-%j.{out,err}`
- **Lipid Stage 01-06 stdout/stderr:** `/project/yli4/ypan/lipid_library/logs` (intentionally separate)

## Historical baseline exceptions

Original protected-file SHA values remain unchanged. These exactly pinned
migrated versions differ only in deployment paths, related comments or tests.
**They are not described as byte-identical to upstream.**

| Path-migrated protected file | Exception |
|---|---|
| `model/HEART_H200_checkpoint_best_embedding_evaluation.ipynb` | Exact SHA pinned; deployment path/comments/tests only |
| `model/HEART_best_checkpoint_embedding_evaluation.ipynb` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/README_HEART.md` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/configs/full_pretrain.yaml` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/configs/pilot.yaml` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/scripts/heart_lib.sh` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/scripts/pretrain_heart-h200.sh` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/scripts/pretrain_heart.sh` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/scripts/pretrain_smoke.sh` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/tests/test_launcher.py` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/tests/test_scripts.py` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/tools/inspect_real_lmdb.py` | Exact SHA pinned; deployment path/comments/tests only |
| `model/pretrain/tools/scan_lmdb_smiles.py` | Exact SHA pinned; deployment path/comments/tests only |

## Scientific scope

Only directory/layout defaults, related comments/docs/examples, exact-path tests,
and integrity tooling were changed. There is **no** Stage 01-04 rerun,
no modification of LMDB, no loosened Stage 05 QC thresholds, no model, optimizer
or loss changes, and **no** production training launch.

`bin/heart check` may report library incompleteness because the Stage 05 QC
failure remains a separate unresolved question. Do not equate path correctness
with readiness for continual pretraining.
