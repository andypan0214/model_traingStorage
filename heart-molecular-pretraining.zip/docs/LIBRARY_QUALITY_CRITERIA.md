# Lipid library — production-quality criteria and conformer semantics

## 1. Conformer generation settings (unchanged; scientifically justified as LUMI-faithful)

| Setting | Value | Source |
|---|---|---|
| Embedding | RDKit ETKDGv3, one embedding per attempt, `randomSeed = seed_start + attempt` | LUMI-lab `smi2_3Dcoords` @ `611e02b` |
| Retry on embed failure | heavy-atom embedding with `maxIterations=4000`, then `AddHs(addCoords=True)` | LUMI |
| Optimisation | `MMFFOptimizeMolecule` (RDKit default 200 iterations; non-convergence is kept, as in LUMI) | LUMI |
| Slots | `n_3d = 10`, at most `max_try = 15` attempts | LUMI pretraining path |
| `seed_start` | **0** (LUMI-faithful) | reviewer decision recorded in every shard receipt |
| Stored 2D slot | **none** (`STORE_2D=0`); HEART adds one 2D conformer at training time | audited general ligand policy; measured by the mandatory check (§3) |
| > 400 atoms | 2D only in all slots (then skipped unless `--allow-2d-only`) | LUMI |

None of these was changed in v2; they are part of the writer configuration fingerprint, so changing any
of them requires a new output directory. Changing `seed_start` to 1 would avoid one duplicate slot (below)
but would depart from the LUMI reference and the audited general data; it is **not** done.

## 2. What "10 coordinate slots" does and does not mean

Every accepted record stores exactly 10 coordinate arrays. That is **not** the same as 10 distinct,
successfully embedded 3D conformers:

1. **2D fill-ins.** If fewer than 10 of the ≤15 attempts embed, the missing slots hold the molecule's 2D
   coordinates (z = 0). They are counted per record (`records.csv.gz`: `n_3d_success`, `n_2d_filled`),
   audited against the LMDB in stage 05 (`--audit-fallback`: flat slots must equal `n_2d_filled`), and
   limited by the criteria below. A record with **zero** 3D embeddings is skipped, never stored.
2. **Duplicate seeds.** In RDKit (verified with 2024.09.6) ETKDG `randomSeed=0` gives the same embedding as
   `randomSeed=1`. With `seed_start=0` the first two 3D slots are therefore normally identical, so a fully
   successful record usually has **9 distinct** 3D conformers in 10 slots (LUMI has the same property).
3. **Convergent minima.** Different seeds can relax to the same MMFF minimum. `n_distinct_3d` counts
   conformers distinct at 1e-3 Å RMS of the coordinate arrays (no alignment).

`quality_report.json` reports the histograms of `n_3d_success` and of `n_distinct_3d`, the mean number of
distinct 3D conformers per record and the fraction of records whose 10 slots are all distinct. The local
test library confirms the effect (mean distinct < 10; `test_seed_start_0_gives_fewer_distinct_conformers_than_slots`).
Because the continual task samples one slot per view, a duplicate slot slightly raises the chance that
the two contrastive views start from the same geometry. Masking and noise still make the views differ.

## 3. Mandatory general-policy check (before stage 04)

`python -m lipid_library.general_policy` measures the REAL general `train.lmdb` / `valid.lmdb` (256
records per split, spread over each file, opened read-only with `lock=False`). It checks:

* every sampled record stores exactly `n_3d + STORE_2D` = 10 slots;
* the dominant profile is `10/0` (10 stored, 0 flat);
* the record fields are `smi`/`atoms`/`coordinates`;
* the lipid `dict.txt` is byte-identical to the general one.

It runs in two places, and both fail closed:

* `bin/heart library --submit`, whenever the plan contains stage 04 (pilots are reported, not refused). The result is saved as `<lipid_root>/jobs/general_policy_check-<time>.json`.
* Inside `04_conformers_pool.sh`, before any work. The result is saved as `<lmdb>/general_policy_check.json`.

## 4. Stage-05 production criteria (`config/heart_v2.yaml` → `library.quality`)

| Criterion | Default | Rationale |
|---|---|---|
| `max_enumeration_failure_fraction` | 0.05 | Ugi-4CR combinations without a product. Reasons are reported. |
| `max_skipped_fraction` | 0.02 | Stage-04 input rows not stored, for any reason. Every reason and category is reported. |
| `max_unsupported_atom_records` | 0 | No vocabulary change is allowed: an atom outside `dict.txt` must be investigated. |
| `max_records_with_2d_fill_fraction` | 0.05 | Records with at least one 2D slot posing in a 3D position. |
| `max_2d_fill_slot_fraction` | 0.01 | 2D fill-in slots as a share of all stored 3D slots. |
| `max_validation_problems` | 0 | Record-level QC of every shard. |
| `min_validation_records_per_shard` | 500 | Validation depth per shard, or every record of a smaller shard. Every shard must be validated. |
| `require_full_fallback_audit` | true | Every validated record is cross-checked against `records.csv.gz`. |

The thresholds are engineering limits chosen before any production data exists. They are not
measured values. If a real run exceeds one, look at `quality_report.md` (by reason/category), then decide:
either fix the cause, or raise the limit in `config/heart_v2.yaml` in a commit that explains why.

* **Production library:** any exceeded limit sets `passed: false`. Stage 05 then exits non-zero and writes no `library_ready.json`, so continual training cannot start.
* **Smoke/pilot library:** the report is produced but the limits are not enforced.

**Reported even when no limit applies:**

* Enumeration failure reasons and dedup drops.
* Skip reasons and categories: conformer failure, no 3D embedding, atom limit, atom outside `dict.txt`, other.
* ETKDG/MMFF attempt counters: attempts, embed failures, MMFF failures, exceptions, heavy-atom retries.
* The `n_3d_success` and `n_distinct_3d` histograms.
* Validation mode (`full` when every stored record was checked, otherwise `sampled`), coverage fraction and the minimum depth per shard.

## 5. Shard integrity after stage 05 (continual readiness)

Stage 05's finalize recomputes the sha256 of every shard, which is the first full verification. `library_ready.json` then
records an integrity table (size, mtime, sampled digest of 4 × 256 KiB blocks per shard). Later checks:

| Check | When | Cost (~3,050 shards, ~0.4 TB) | Detects |
|---|---|---|---|
| quick | every `bin/heart continual …` call and every continual job start | ~3 GB read + `stat` | missing, truncated or rewritten shards; corruption inside the sampled blocks; any change of mtime |
| full | stage 05; `bin/heart library --verify-full --submit` (16-CPU job) | 0.4 TB read, parallel | any byte change (sha256 == `manifest.json`) |

A production continual submission requires both: a passing quick check, and a passing full verification
younger than `continual.full_verify_max_age_days` (14). A changed mtime with unchanged sampled content is
refused until a full verification proves the content (then the table is refreshed). The quick check
cannot detect a corrupted byte outside its sampled blocks; that is why the full verification has a
maximum age (`test_unsampled_corruption_passes_quick_but_fails_full_verification`).
