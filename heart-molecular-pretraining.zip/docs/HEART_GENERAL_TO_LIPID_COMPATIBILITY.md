# HEART general ligand data ↔ lipid library ↔ continual model: compatibility gates

Status values: **PASS_LOCAL** = proven by the local test suite on synthetic data with the real code paths
(Windows CPU, Python 3.11, RDKit 2024.9.6, torch 2.2.2+cpu, Uni-Core `ace6fae`); **PENDING_HPC** = needs the
read-only CMRI check named in the last column; **FAIL** = known incompatibility (none).
No gate is claimed `PASS` on real CMRI data: the real general LMDBs, the real lipid library and the real
H200 checkpoint were not available to this development session.

| # | Gate | Local evidence | Status | CMRI check (read-only) |
|---|---|---|---|---|
| 1 | General reference data stays read-only; never copied to Git | No code writes under `paths.general_data`; `lipid_lib.sh` refuses `LIPID_ROOT` inside it; `.gitignore` blocks `*.lmdb`, `*.pt`, `*.xlsx` | PASS_LOCAL | `bash scripts/check_heart_hpc_readonly.sh` G1 |
| 2 | Lipid output layout: `manifest.json`, `splits.json`, `validation.json`, per-shard `shard.json` receipts, provenance, **`library_ready.json`** | `test_v2_library_pipeline.py::test_pool_library_is_complete_ready_and_production_shaped` | PASS_LOCAL | G4 (`lipid_library.ready verify`) |
| 3 | Keys: contiguous ASCII integers per LMDB (no SMILES keys) | `validate_lmdb` key checks; `test_continual_loader.py::test_smiles_keyed_lumi_lmdb_is_rejected`; actual `MergedSampledLMDBDataset` reads the v2 shards (`test_v2_continual_integration.py`) | PASS_LOCAL | G5 (`check_continual_data.py` on real data) |
| 4 | Records exactly `smi`/`atoms`/`coordinates`; float32 `(n_atoms,3)`; atom order = `AddHs(smi)`; `--only-polar 0`, ≤256 heavy atoms; atoms ⊂ general `dict.txt` (no vocabulary change) | stage-05 `validate_lmdb` on every shard; batch built with the general dictionary has no token ≥ vocab (`test_actual_continual_task_builds_independent_view_batches`) | PASS_LOCAL | G5; stage 05 on CMRI (`validation.json`) |
| 5 | Stored slots: 10 3D slots, `STORE_2D=0`; 2D added once at training time; two independent views; fallback slots audited, not counted as 3D | `manifest`: `stored_2d_conformer=[False]`, `coordinate_slots_per_record=[10]`; `--audit-fallback` mismatch test; `test_training_time_2d_slot_is_added_once`; independent-view test | PASS_LOCAL | G2 (real general profile must be `10/0`), G5 (profiles equal) |
| 6 | Completeness: every enumerated combination accounted for (products + failures = combinations; dedup drops; shard inputs sum); all shards present and hash-verified; train/valid disjoint and non-empty; nonzero exit when incomplete | `test_pool_stops_at_the_deadline_and_reports_incomplete` (no manifest, no ready receipt, resubmit list); existing `test_review_fixes.py` P0-1 tests | PASS_LOCAL | stage 05 on CMRI |
| 7 | Actual general loader + `MergedSampledLMDBDataset` + `unimol_contrastive_continual` + collater → batch shapes, independent views, distances/edge types, finite loss and gradients | `test_v2_continual_integration.py` (4 tests) on the pool-built library + a general-format stand-in | PASS_LOCAL | G5 + continual smoke run (`bin/heart continual --smoke --submit`, needs approval) |
| 8 | `checkpoint_best.pt` (`unimol_contrastive`) → continual model (`unimol_contrastive_continual`): identical parameter names/shapes and dictionary, no partial load; optimizer/LR/scaler/update counter reset; general checkpoint untouched | `test_continual_loader.py` init tests (strict refusal of partial/arch/vocab changes); `test_continual_scripts.py::test_launcher_new_stage_then_resume_on_cpu` (real `unicore-train`, tiny model) | PASS_LOCAL | G6 (`bin/heart continual --check` = runner `HEART_DRY_RUN=1` with the real checkpoint) |
| 9 | No leakage: lipid train/valid shard lists disjoint; weights are per-epoch sampling fractions, real `n_sampled` written to `mixture_report.json` | `test_valid_split_reads_only_lipid_valid_shards`; `test_weights_are_per_dataset_fractions_not_a_batch_ratio`; `test_mixture_report_records_real_counts` | PASS_LOCAL | read `mixture_report.json` of the smoke run |

## Mixture semantics (gate 9)

`general_data_weight 0.5` and `lipid_data_weight 1.0` are the fractions of each dataset sampled (without
replacement) per epoch, as in LUMI. With the real sizes the effective proportion is
`0.5·N_general : 1.0·N_lipid`; it is **not** a 50:50 batch mixture. The runner writes the actual counts to
`<run dir>/mixture_report.json`; report those numbers, not the weights.

## Not claimed

* That the real general `train.lmdb`/`valid.lmdb` have the `10/0` slot profile: the plan states it was
  audited; G2 re-measures it read-only. If G2 reports anything else, stop before stage 04 and re-decide
  `STORE_2D` (the lipid config then changes and must use a new output directory).
* Any H200 throughput, memory or runtime number for stage 04 or continual training.
