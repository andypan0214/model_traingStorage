# Current handoff — 2026-11-16

> **ACTIVE DEPLOYMENT:** Home code `/home/ypan/heart_liver/model_train/heart-molecular-pretraining`; data `/project/yli4/ypan`;
> all new training stdout/stderr `/project/yli4/ypan/runs/h200/slurm`. This supersedes old
> directory paths and progress status in the historical notes below.
> Existing Stages 01–04 finished, Stage 05 QC failed (2D fallback), Stage 06
> not started. Preserve the `heart-molecular-pretraining-v2` rollback checkout.

## Archived notes from before this deployment (historical; do not execute)

# HANDOFF — HEART v2 (for ChatGPT / the next session)

**Repository:** https://github.com/andypan0214/heart-molecular-pretraining-v2 (private)
**Branch:** `v2/lipid-continual` → PR into `main` (see the PR link below). `main` = unchanged upstream `73a5f9d`.
**Code commit described here:** `4d86ded` (hardening pass; first pass `bafd563`). Only docs change after it (`git diff 4d86ded..HEAD --stat`).
**Upstream (read-only, untouched):** `andypan0214/heart-molecular-pretraining` @ `73a5f9d4a624a37dfad0f943093187af06bae5e3` (tag `upstream-baseline-73a5f9d`).
**PR:** https://github.com/andypan0214/heart-molecular-pretraining-v2/pull/1
**Date:** 2026-11-07. Development and tests ran on a Windows CPU machine. **No CMRI job was submitted. No real data, checkpoint or HPC log was available.**

## 1. Status by phase

| Part | Status |
|---|---|
| General pretraining | **COMPLETED and UNCHANGED.** Integrity **PASS**: 69 protected files byte-identical to `73a5f9d` (`bin/heart baseline`, `docs/GENERAL_BASELINE_INTEGRITY.md`). Not re-run, not reconfigured. |
| Lipid library code | Ready. Stage 02 config-lock race fixed. Stage 04 is now a single 250-CPU H200-node job with a per-shard queue. Stage 05 fails closed and writes `library_ready.json`. All tested locally on a tiny real-code library. |
| Lipid library on CMRI | 01 done (1013342). 02 (1013343) task 63 `FAILED 13:0`, other tasks apparently done. 03–05 never ran. **Next: `bin/heart library --resume --dry-run`, then `--submit`.** |
| Continual integration | Code ready. Tested locally: actual task, collator, independent views, one training step, strict init, resume (tiny CPU model). **Never run on H200.** |
| Continual evaluation | Read-only `tools/v2_compare_checkpoints.py` (`bin/heart evaluate --check`). Historical notebooks unchanged. PENDING_HPC. |
| Tests | **One full run on the final committed code `4d86ded` (clean tree): 433 passed, 0 failed, 2 skipped (fork-only)** (`docs/TEST_RESULTS.md`). |
| Hardening pass (PR #1 review) | DONE, see §2a and `docs/CODE_AUDIT.md` §7 (H1–H9). |

## 2. What changed (exact paths)

* **Single config:** `config/heart_v2.yaml` (paths, library + continual settings, SLURM profiles). Precedence: `--set` > `HEART_V2_CONFIG` > file.
* **Orchestrator:** `bin/heart` → `model/pretrain/heart_v2/{config,slurm,cli,status,guard,baseline}.py`.
* **Lipid library:** `model/pretrain/lipid_library/`
  * `stage04_pool.py`: new. One shard per spawned worker process over the unchanged `lmdb_writer.write_shard`.
  * `dirlock.py`: new. Exclusive lock for a pool, shared lock for array tasks.
  * `ready.py`: new. `library_ready.json` receipt.
  * `provenance.py`: atomic lock publish.
  * `lmdb_writer.py`: shared lock in array mode; drop set no longer loaded per task; parallel finalize verification.
  * `validate_lmdb.py`: `--workers`, `--audit-fallback`.
* **Job scripts:** `model/pretrain/scripts/lipid_library/`
  * `04_conformers_pool.sh`: new production Stage 04.
  * `01…05`: v2 repo resolution, `#SBATCH` == config, resource guard.
  * `05_finalize.sh`: workers, audit, ready receipt.
  * `04_conformers_250cpu.sbatch`, `submit_lipid_library_250cpu.sh`, `submit_lipid_library_production_now.sh`, `smoke_lipid_250cpu.sh`: now stubs that print the new command and exit 2.
* **Continual runner:** `model/pretrain/scripts/continual_pretrain_heart-h200.sh`
  * Uses the v2 checkout, not the old hard-coded repo.
  * Resource guard; `HEART_REQUIRE_LIBRARY_READY`; `MAX_OPEN_LMDB_ENVS=auto`.
  * Science unchanged.
* **New tools:** `model/pretrain/tools/v2_compare_checkpoints.py`, `scripts/check_heart_hpc_readonly.sh`.
* **New tests:** `model/pretrain/tests/integration/` (43 tests). Two upstream continual tests were adapted: Stage 05 now uses 16 CPUs, and the runner env now carries `HEART_V2_PROFILE`.
* **Docs:** `docs/CODE_AUDIT.md` (findings F1–F14, task-63 analysis, stage decision), `WORKFLOW_ARCHITECTURE.md`, `HEART_GENERAL_TO_LIPID_COMPATIBILITY.md`, `HPC_INSTALL_AND_RECOVERY.md`, `UPSTREAM_DEPENDENCIES.md`, `TEST_RESULTS.md`, `OVERNIGHT_PROGRESS.md`, `GENERAL_BASELINE_INTEGRITY.md`.

Most important fixes:

* **F1:** under `sbatch`, the v1 lipid jobs ran the **old clone's** code.
* **F2:** the continual runner hard-coded the old repo.
* **F3:** three files gave conflicting Stage 04 resources (`gpu:1` vs `gpu:h200:1`).

## 2a. Hardening pass (2026-11-08, PR #1 review)

* **P0-1 general-policy gate.** `lipid_library/general_policy.py` measures the REAL general `train.lmdb`/`valid.lmdb` read-only: 10 stored slots, dominant profile `10/0`, fields, and an identical `dict.txt`. It runs in two places and both fail closed:
  * `bin/heart library --submit`, whenever the plan contains Stage 04. The report goes to `<lipid_root>/jobs/general_policy_check-*.json`.
  * Inside `04_conformers_pool.sh`.
* **P0-2 shard integrity.**
  * `library_integrity.json` records size, mtime and a sampled digest (4 × 256 KiB blocks) for every shard.
  * A **quick** check (~3 GB of reads for ~0.4 TB) runs on every `bin/heart continual` call and at continual job start.
  * A **full** sha256 verification is done by Stage 05, or by the new `lipid_verify` job (`bin/heart library --verify-full --submit`). It must be younger than `continual.full_verify_max_age_days` (14) to submit.
  * Limit of the quick check: a corrupted byte outside the sampled blocks is only caught by the full check. This is tested and documented.
* **P1-3 drift fails closed.** Configuration drift, a missing `HEART_V2_CONFIG_SHA` or an edited snapshot now refuse to run.
  * **Real bug fixed:** PyYAML parsed the JSON snapshot's `2e-05` as a string, so job-side hashes never matched submission hashes. This was invisible while drift only warned.
* **P1-4 read-only check and full diagnostics.** `bin/heart continual --check` is strictly read-only, proven by before/after directory-tree snapshots. The acceptance script saves everything to `~/heart_v2_acceptance/<time>/`: `full.log`, `summary.txt`, policy/status JSON, and `task63/` with sacct `--long`, seff and **complete** task-63 log copies.
* **P1-5 Stage 05 production criteria.** `lipid_library/quality.py` applies the `library.quality` thresholds (`docs/LIBRARY_QUALITY_CRITERIA.md`) and writes `quality_report.json`/`.md`. It reports:
  * every Ugi failure;
  * skips by reason and category;
  * ETKDG/MMFF attempt counters;
  * 2D-fill record and slot rates;
  * histograms of successful 3D embeddings and of distinct 3D conformers;
  * full vs sampled validation coverage.

  A production library that fails a criterion gets no `library_ready.json`.
* **P2-7 settings kept.** ETKDGv3/MMFF and `seed_start=0` are unchanged. Documented and measured: 10 slots ≠ 10 distinct 3D conformers (seeds 0 and 1 coincide in RDKit, and 2D fill-ins exist).
* **P2-8 benchmark.** `bin/heart bench [--submit]` runs 64/128/250 workers, ≤ 100k molecules each, on the production Stage 04 allocation, one run after another. `python -m lipid_library.bench_report` compares the runs. **Not run.**
* **P2-9 GPU type.** The guard previously read non-existent SLURM variables, so the GPU type was never actually verified. It now uses `scontrol show job -d` (`AllocTRES`/`TresPerNode`/`GRES`), `nvidia-smi` names and `SLURM_GPUS_ON_NODE`. It fails closed when the type can't be verified; the override is `HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE=1`.

## 3. The two H200 job profiles (`config/heart_v2.yaml`)

| | Stage 04 (lipid conformers) | Continual pretraining |
|---|---|---|
| sbatch | `--partition=gpu --nodes=1 --ntasks=1 --cpus-per-task=250 --mem=500G --gres=gpu:h200:1 --nodelist=cmri-gpu04 --time=2-00:00:00 --signal=B:USR1@2700` | `--partition=gpu --nodes=1 --ntasks-per-node=1 --cpus-per-task=16 --mem=200G --gres=gpu:h200:1 --time=2-00:00:00 --signal=B:USR1@1800` |
| Work | 250 RDKit worker processes (logical CPUs; benchmark 64/128/250 later) | batch 448, update-freq 1, 4 DataLoader workers, fp16, 200,000 updates, lr 2e-5, warmup 1000, wd 1e-4, data weights 0.5 / 1.0 |
| Threads | `OMP/MKL/OPENBLAS_NUM_THREADS=1` | as the proven general H200 setup |

Other stages: CPU-only on `gpu` (01: 1 CPU/4G; 02: 64 × 1 CPU/4G; 03: 1/16G; 03b: 1/8G; 05: 16/64G).

No contradictory sources remain:

* Every `#SBATCH` header equals its profile (tested).
* The v1 launchers carry no directives.
* Each job checks its real allocation (`heart_v2.guard`).
* Config validation refuses generic, T4 or `h200a` GRES for Stage 04 and continual, a GPU on CPU stages, and the 250-CPU/500G profile for continual.

## 4. Tests

| Kind | Result |
|---|---|
| Full pytest, ONE run on the final committed code `4d86ded` (`model/pretrain/tests`, incl. 71 v2 integration tests) | **433 passed, 0 failed, 2 skipped** (fork-only). First pass: 405 passed at `bafd563` |
| Upstream baseline before changes | 362 passed, 2 skipped |
| Mocked SLURM (actual argv) | Library chain of 6 jobs (deps `afterok` / `afterany`), resume `--array=63`, continual normal and smoke, policy-gate refusal, tampered-snapshot refusal, bench chain: PASS_LOCAL |
| ShellCheck 0.10.0 (`-S warning`) | Lipid/continual scripts clean, except one upstream-identical warning in the continual runner |
| Clean clone from GitHub | `bin/heart check` PASS, `bin/heart baseline` PASS |
| Secret/binary scan | Clean: no `.pt`, `.lmdb`, `.xlsx` or tokens; largest tracked file 92 KB |
| Real CMRI data / H200 | **PENDING_HPC** (all of G1–G7) |

## 5. Remaining HPC validation (in this order; each needs the user)

1. Clone the v2 repo next to the old checkout (`docs/HPC_INSTALL_AND_RECOVERY.md` §1), then run `bin/heart check` and `bin/heart baseline`.
2. Run `bash scripts/check_heart_hpc_readonly.sh --out ~/heart_v2_acceptance.txt`.
   * G2 must show the real general slot profile `10/0`; this confirms `STORE_2D=0`.
   * G7 prints the task-63 evidence. Record the real root cause in `docs/CODE_AUDIT.md` §5.
3. Run `bin/heart library --resume --dry-run`, then `--submit`. The submission measures the general slot policy first and refuses on a mismatch. Optionally run `bin/heart bench --submit` first (`HPC_INSTALL_AND_RECOVERY.md` §6).
4. Once `bin/heart library --status` shows Stage 05 DONE, read `<lmdb>/quality_report.md`, then re-run the acceptance script; G4 (quick integrity), G5 and G6 must PASS.
5. Run `bin/heart continual --smoke --submit`. Inspect losses, `mixture_report.json`, the checkpoint, and that a resubmission resumes.
6. Run `bin/heart continual --submit`; repeat it until 200,000 updates. Then run `bin/heart evaluate --check` and the unchanged embedding notebook with the continual checkpoint.

## 6. Open risks / decisions for the user

* **Task 63 cause** is unknown (`ROOT_CAUSE_NOT_CONFIRMED`). Recovery does not depend on it.
* **Stage 04 runtime on CMRI** is unmeasured. At ~2 s/molecule/worker, 15.24M molecules ÷ 250 workers ≈ 34 h. Hyper-threading may make each worker slower. If it runs past the 2-day limit, `--resume` continues it.
* **Stage 04 output size:** roughly 15M × ~26 kB ≈ 0.4 TB (assumed). The pool's disk preflight measures the real value after the first shards.
* **`MAX_OPEN_LMDB_ENVS`:** 64 is the default. `auto` (all shards) is likely faster but untested on H200.
* **Workers:** `library.stage04_workers: 250` assumes 250 logical CPUs are useful; benchmark before relying on it.
* **Not merged:** the upstream branch `perf/lipid-library-hpc-optimization` (`CODE_AUDIT.md` §6).
* **Merging the PR into `main`** is the user's decision.
