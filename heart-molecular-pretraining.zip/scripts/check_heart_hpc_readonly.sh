#!/usr/bin/env bash
# =============================================================================
# HEART -- READ-ONLY acceptance checks on CMRI (login node or a small
# interactive CPU job). Submits nothing and never writes into the repository,
# the general data, the checkpoints or the lipid library. Its only output is a
# NEW diagnostics directory (default /project/yli4/ypan/heart_evaluation/acceptance/<timestamp>/):
#   full.log                 everything printed below (stdout + stderr)
#   summary.txt              one line per gate
#   general_policy.json      G2 measurement
#   library_status.json      G4 stage-by-stage receipts
#   task63/                  G7: sacct/seff output and COMPLETE copies of every
#                            stage-02 task-63 log (.out/.err), not just a tail
#
#   bash scripts/check_heart_hpc_readonly.sh [--out-dir DIR] [--job 1013343] [--task 63]
#
# Gates (PASS / FAIL / PENDING_HPC / SKIPPED, with evidence in full.log):
#   G0  pipeline config valid, #SBATCH headers == config, baseline hashes with explicit path-only exceptions
#   G1  general ligand data present: train.lmdb, valid.lmdb, dict.txt
#   G2  general slot policy measured on the REAL LMDBs == lipid policy (10 slots, STORE_2D=0)
#       (the same mandatory check bin/heart runs before submitting stage 04)
#   G3  general H200 checkpoint readable; task/arch/updates printed (opened read-only)
#   G4  lipid library status from receipts + quick shard-integrity check when ready
#   G5  REAL general + lipid compatibility: tools/check_continual_data.py
#   G6  continual runner dry run (bin/heart continual --check; strictly read-only)
#   G7  historical Stage-02 task evidence (not an instruction to rerun any job)
# =============================================================================
set -o pipefail
repo="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
outdir="" job=1013343 task=63
while [ $# -gt 0 ]; do
    case "$1" in
        --out-dir) outdir="$2"; shift 2 ;;
        --job) job="$2"; shift 2 ;;
        --task) task="$2"; shift 2 ;;
        *) echo "usage: $0 [--out-dir DIR] [--job ID] [--task N]" >&2; exit 2 ;;
    esac
done
outdir="${outdir:-/project/yli4/ypan/heart_evaluation/acceptance/$(date '+%Y%m%d-%H%M%S')}"
case "$(cd "$(dirname "$outdir")" 2>/dev/null && pwd)/" in "$repo"/*) echo "ERROR: --out-dir must be outside the repository" >&2; exit 2 ;; esac
mkdir -p "$outdir/task63" || { echo "ERROR: cannot create $outdir" >&2; exit 2; }
exec > >(tee -a "$outdir/full.log") 2>&1

heart="$repo/bin/heart"
py="${HEART_PYTHON:-/home/ypan/.conda/envs/heart_gpu/bin/python}"
command -v "$py" >/dev/null 2>&1 || py=python3
export HEART_PYTHON="$py" PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
declare -a results=()
gate() { results+=("$(printf '%-3s %-12s %s' "$1" "$2" "$3")"); printf '\n### %s: %s -- %s\n' "$1" "$2" "$3"; }
cfgget() { (cd "$repo/model/pretrain" && "$py" -c 'import sys
from heart_v2 import config as C
cfg, _, _ = C.load()
node = cfg
for k in sys.argv[1].split("."): node = node[k]
print(node)' "$1"); }

echo "HEART read-only acceptance  $(date '+%F %T')  host $(hostname)  repo $repo  diagnostics $outdir"
git -C "$repo" log -1 --format='commit %H (%s)' 2>/dev/null
git -C "$repo" status --short 2>/dev/null | head -20

if "$heart" check; then gate G0 PASS "config, headers and frozen baseline"; else gate G0 FAIL "see bin/heart check output"; fi

data="$(cfgget paths.general_data)"; ckpt="$(cfgget paths.general_checkpoint)"
lroot="$(cfgget paths.lipid_root)"; lmdb="$lroot/lmdb"
n3d="$(cfgget library.n_3d)"; s2d="$(cfgget library.store_2d)"
if [ -r "$data/train.lmdb" ] && [ -r "$data/valid.lmdb" ] && [ -r "$data/dict.txt" ]; then
    ls -lh "$data/train.lmdb" "$data/valid.lmdb" "$data/dict.txt"
    gate G1 PASS "$data"
else
    gate G1 FAIL "general ligand data missing/unreadable under $data"
fi

if [ -r "$data/train.lmdb" ]; then
    if (cd "$repo/model/pretrain" && "$py" -m lipid_library.general_policy "$data" --n-3d "$n3d" --store-2d "$s2d" \
            --sample 256 --json-out "$outdir/general_policy.json"); then
        gate G2 PASS "real general slot policy == lipid policy (${n3d} slots, STORE_2D=${s2d})"
    else
        gate G2 FAIL "general slot policy differs: do NOT run stage 04; see $outdir/general_policy.json"
    fi
else
    gate G2 SKIPPED "no general data"
fi

if [ -r "$ckpt" ]; then
    if "$py" - "$ckpt" <<'PY'
import sys, torch
try:
    ck = torch.load(sys.argv[1], map_location="cpu", weights_only=False)
except TypeError:
    ck = torch.load(sys.argv[1], map_location="cpu")
a = ck.get("args")
print("task", getattr(a, "task", None), "| arch", getattr(a, "arch", None),
      "| updates", ck["optimizer_history"][-1]["num_updates"], "| params", len(ck["model"]))
PY
    then gate G3 PASS "$ckpt readable (opened read-only)"; else gate G3 FAIL "cannot read $ckpt"; fi
else
    gate G3 FAIL "general checkpoint not found: $ckpt"
fi

"$heart" library --status || true
"$heart" --json library --status > "$outdir/library_status.json" 2>&1 || true
if (cd "$repo/model/pretrain" && "$py" -m lipid_library.ready verify "$lmdb"); then
    gate G4 PASS "lipid library READY; quick integrity of every shard OK ($lmdb/library_ready.json)"
    ready=1
else
    gate G4 PENDING_HPC "Stage 01-04 complete; Stage 05 failed QC (2D fallback). Do NOT regenerate shards. Decide training-view policy first."
    ready=0
fi
[ -r "$lmdb/quality_report.md" ] && cp "$lmdb/quality_report.md" "$outdir/" 2>/dev/null

if [ "$ready" = 1 ]; then
    if (cd "$repo/model" && "$py" pretrain/tools/check_continual_data.py --general "$data" \
            --lipid-splits "$lmdb/splits.json" --sample 64 --lipid-shards 256 --json-out "$outdir/continual_data.json"); then
        gate G5 PASS "real general + real lipid LMDBs compatible (keys, fields, slots, dict, 2D policy)"
    else
        gate G5 FAIL "check_continual_data.py rejected the real data (see full.log)"
    fi
    if "$heart" continual --check; then
        gate G6 PASS "general checkpoint strictly matches the continual model (read-only dry run)"
    else
        gate G6 FAIL "continual dry run failed (see full.log)"
    fi
else
    gate G5 PENDING_HPC "needs the complete lipid library"
    gate G6 PENDING_HPC "needs the complete lipid library (runner dry run checks data first)"
fi

# ---- G7: stage-02 task evidence, saved completely ----
t63="$outdir/task63"
if command -v sacct >/dev/null 2>&1; then
    sacct -j "$job" --format=JobID%22,JobName%18,State,ExitCode,DerivedExitCode,Start,End,Elapsed,NodeList,MaxRSS,Reason%30 -P \
        > "$t63/sacct_job_${job}.txt" 2>&1
    sacct -j "${job}_${task}" --long -P > "$t63/sacct_task_${job}_${task}_long.txt" 2>&1
    command -v seff >/dev/null 2>&1 && seff "${job}_${task}" > "$t63/seff_${job}_${task}.txt" 2>&1
    echo "--- sacct ${job} (all tasks)"; cat "$t63/sacct_job_${job}.txt"
fi
found=0
for f in "$lroot"/logs/*"${job}_${task}".* "$lroot"/logs/*"${job}_${task}"-* ; do
    [ -f "$f" ] || continue
    cp -p "$f" "$t63/" && found=$((found + 1))
    echo "===== FULL $f ($(wc -l < "$f") lines) ====="; cat "$f"
done
for f in "$lroot"/logs/*"${job}"_*; do
    [ -f "$f" ] && ls -la "$f"
done > "$t63/all_task_logs_of_job_${job}.txt" 2>/dev/null
if [ "$found" -gt 0 ]; then
    gate G7 PENDING_HPC "copied $found complete task-${task} log(s) to $t63: read them and record the root cause in docs/CODE_AUDIT.md section 5"
elif command -v sacct >/dev/null 2>&1; then
    gate G7 PENDING_HPC "no task-${task} log under $lroot/logs; sacct saved in $t63"
else
    gate G7 SKIPPED "neither sacct nor task logs available here"
fi

echo; echo "===== SUMMARY ====="
printf '%s\n' "${results[@]}" | tee "$outdir/summary.txt"
echo "diagnostics saved in $outdir"
printf '%s\n' "${results[@]}" | grep -q ' FAIL ' && exit 1
exit 0
